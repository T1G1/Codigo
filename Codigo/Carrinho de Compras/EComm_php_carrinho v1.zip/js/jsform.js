/* 
 * retirado de https://blog.tompawlak.org/number-currency-formatting-javascript
 */
function currencyFormatPT (num) {
    return num
       .toFixed(2) // always two decimal digits
       //.replace(".", ",") // replace decimal point character with ,
       .replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1 ") //+ " €" // use . as a separator
}

/* 
 * retirado de http://stackoverflow.com/questions/4801655/how-to-go-to-a-specific-element-on-page
 */

(function($) {
    $.fn.goTo = function() {
        $('html, body').animate({
            scrollTop: $(this).offset().top + 'px'
        }, 'fast');
       // return this; // for chaining...
    };
})(jQuery);


