<?php
/**
 * PHP
 *
 * Regista a encomenda
 *
 * @author Eduardo Fernandes
 */
session_start();


include_once 'funcBase.php';
include_once 'funcoes_bd.php';
include_once 'multibanco.php';


if (!isset($_SESSION['idcliente'])) {
    redirect();
} else {
    $i = 0;
    $keys = array_keys($_REQUEST);
    $idcliente = $_SESSION['idcliente'];
    $idEncomenda = $_REQUEST['idEncomenda'];
    $idTipoPagLoja = $_REQUEST['tipopagamento'];
    $tipoe = explode('|', $_REQUEST["tipoentrega"]);
    $custoEntrega = $tipoe[2];
    $txIvaEntr = $tipoe[1];
    $valorTotal = $_REQUEST['valorTotalComp'];
    $moradaEntrega = $_REQUEST['novaMorada'];
    $codpostal = $_REQUEST['codpost'];
    $tipoentr_loja_idTipoEntrLoja = $tipoe[0];
    $aPagar = $valorTotal + $custoEntrega;

    $num = $_REQUEST['num'];

    $query = "UPDATE  encomendas SET "
            . "idCliente = '$idcliente', "
            . "idTipoPagLoja = '$idTipoPagLoja', "
            . "custoEntrega = '$custoEntrega', "
            . "txIvaEntr = '$txIvaEntr', "
            . "valorTotal = '$valorTotal', "
            . "moradaEntrega = '$moradaEntrega', "
            . "codpostal = '$codpostal', "
            . "tipoentr_loja_idTipoEntrLoja = '$tipoentr_loja_idTipoEntrLoja' "
            . "WHERE  idEncomenda = '$idEncomenda'";
    $connect = ligar_base_dados();
    $results = perform_query($query);
    $today = date("Ymd");
    $query = "INSERT INTO estado_encomenda_data ("
            . "idEncomenda, "
            . "idEstado, "
            . "dataEstado "
            . ") VALUES ("
            . "$idEncomenda, "
            . "2, "
            . "$today "
            . ");";
    $results = perform_query($query);
    $i = 0;
    while ($i < ($num * 5)) {
        // echo $num;

        $a = $i + 1;
        $b = $i + 2;
        $c = $i + 3;
        $d = $i + 4;
        $idDetEnc = $_REQUEST[$keys[$i]];

        $idProduto = $_REQUEST[$keys[$a]];
        $quantidade = $_REQUEST[$keys[$b]];
        $precoVenda = $_REQUEST[$keys[$b]] * round(($_REQUEST[$keys[$c]] * (1 + $_REQUEST[$keys[$d]])), 2);
        $tIva = $_REQUEST[$keys[$d]];


        $query = "UPDATE detencomenda SET "
                . "idEncomenda = '$idEncomenda', "
                . "idProduto = '$idProduto', "
                . "quantidade = '$quantidade', "
                . "precoVenda = '$precoVenda', "
                . "tIva = '$tIva' "
                . "WHERE idDetEnc = '$idDetEnc';";

        $results = perform_query($query);



//---------- atualiza stocks            
        $query1 = "UPDATE produtos SET "
                . "stockActual = stockActual - '$quantidade' "
                . "WHERE idProduto = '$idProduto';";
        $results = perform_query($query1);
        $i+=5;
    }

//---------- apesenta a referencia MultiBanco
    $query = "select * from clientes where idCliente='$idcliente';";

    $results = perform_query($query);
    if (mysql_num_rows($results) > 0) {

        $row = mysql_fetch_array($results);
        $nomeCli = $row[2];
        $email = $row[4];
        $telefone = $row[3];
    }
    ?>
    <html>
        <head>
            <title><?= $_SESSION['desigcomercial'] ?> - Hosted by T1G1</title>
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
            <!-- Optional theme -->
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap-theme.min.css" integrity="sha384-fLW2N01lMqjakBkx3l/M9EahuwpSfeNvV63J5ezn3uZzapT0u7EYsXMjQV+0En5r" crossorigin="anonymous">
            <!-- Latest compiled and minified JavaScript -->
            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
            <script src="/js/jquery.min.js"></script>
            <link href="css/styles.css" type="text/css" rel="stylesheet" />
            <link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css"/>
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>

            <script src="js/jsform.js"></script>
        </head>

        <body >
            <div class="container" style=" width:30%; margin:0 auto;">
                <div class = "panel panel-info"  style="height: 400px">
                    <div class = "panel-heading"> <h2 class = "panel-title">Encomenda Registada</h2>
                    </div>
                    <div class = "panel-body">
                        <p>
                            Caro(a)  <?= $nomeCli ?>
                        </p>

                        <p>
                            Queira proceder ao pagamento usando os seguintes dados:
                        </p>
                        <div>
                            <p>
                                Dados de pagamento:
                                <?php GenerateMbRef(99012, 123, $idEncomenda, $aPagar) ?>
                            </p>
                            <p>
                                A sua encomenda será despachada até 24h após a confirmação do pagamento.
                            </p>
                            <p>
                                Obrigado pela sua preferência.
                            </p>
                            <p></p>
                        </div>
                    </div>
                </div>

                <?php
            }
            ?>

        </div>

    </body>

</html>


