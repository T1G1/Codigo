<?php

/**
 * PHP
 *
 * Adicionar itens ao carrinho de compras
 * sem sign in feito
 *
 * @author Eduardo Fernandes
 */
session_start();


include_once 'funcBase.php';
include_once 'funcoes_bd.php';

//---------- Para guardar o carrinho de compras é necessário fazer sign in
if (!isset($_SESSION['idcliente'])) {
    redirect();
} else {

//---------- Se a chamada tiver sido feita já com o sign in feito
    if (isset($_GET['idProd'])) {

//---------- Apagar cookie e encaminhar para o carrinho de compras

        $results = checkCarrinhoBD();
        if (mysql_num_rows($results) > 0) {

//---------- Se o utilizador já tiver um carrinho na base de dados
//---------- acrescenta os itens do cookie a esse carrinho
            $valorTotalComp = 0;
            $i = 0;
            while ($row = mysql_fetch_array($results)) {
                $i++;
                $idDetEnc = $row[0];
                $idEncomenda = $row[1];
                $idProduto = $row[2];
                $quantidade = $row[3];
                $precoUnit = $row[12];
                $tIva = $row[20];
                $precoVenda = round($precoUnit * (1 + $tIva), 2);
                $desigProduto = $row[8];
                $stock = $row[17];
                $imagem = $row[19];
                $subTotal = $precoVenda * $quantidade;
            }

            //se select det encomendas para idProd e idCliente e idEstado
            //adiciona uma unidade
            //se não,insere encomenda e detalhe
            addBdItem($idEncomenda, $_GET['idProd']);

//---------- Apagar cookie e encaminhar para o carrinho de compras
            setcookie("carrinho", null, time() - 3600, '/');
            header('Location: listaCarrinho.php', true, $statusCode);
        }
    }

    $i = 0;
    $user = $_SESSION['idcliente'];
    $idLoja = $_SESSION['idloja'];

    $results = checkCarrinhoBD();

    if (mysql_num_rows($results) > 0) {

//---------- Se o utilizador já tiver um carrinho na base de dados
//---------- acrescenta os itens do cookie a esse carrinho
        $valorTotalComp = 0;
        $i = 0;
        while ($row = mysql_fetch_array($results)) {
            $i++;
            $idDetEnc = $row[0];
            $idEncomenda = $row[1];
            $idProduto = $row[2];
            $quantidade = $row[3];
            $precoUnit = $row[12];
            $tIva = $row[20];
            $precoVenda = round($precoUnit * (1 + $tIva), 2);
            $desigProduto = $row[8];
            $stock = $row[17];
            $imagem = $row[19];
            $subTotal = $precoVenda * $quantidade;
        }
        if (isset($_COOKIE["carrinho"])) {

//---------- verifica se há um cookie "carrinho"
//---------- se houver adiciona os produtos ao carrinho
            addBdCookie($idEncomenda);
        }
    } else {
        if (isset($_COOKIE["carrinho"])) {

//---------- Se o utilizador não tiver um carrinho na base de dados
//---------- cria o carrinnho na base de dados com os itens do cookie
            addBdCookie(null);
        } else {
//---------- Se o utilizador não tem carrinho na base de dados nem tem cookie
            echo "<td colspan=\"6\">Não tem um carrinho ativo.</td></div>";
        }
    }
}

/**
 * PHP
 * 
 * Adicionar os itens do cookie "carrinho"
 * à base de dados
 *
 * @author Eduardo Fernandes
 */
function addBdCookie($idEncomenda) {
    global $user;
    global $idLoja;
    if ($idEncomenda === null) {

//---------- Carrega dados do cliente
        $query = "SELECT c.*, cp.local "
                . "FROM clientes as c "
                . "inner join codigos_postais as cp "
                . "on c.codPostal = cp.codPostal "
                . "where idCliente='" . $user . "';";
        $results_cliente = perform_query($query);
        $row_cliente = mysql_fetch_array($results_cliente);
        $codpostal = $row_cliente[7];
        $morada = $row_cliente[6];

//---------- Insere nova encomenda
        $query = "INSERT INTO encomendas("
                . "idCliente,idTipoPagLoja, "
                . "txIvaEntr, "
                . "moradaEntrega, codpostal, "
                . "tipoentr_loja_idTipoEntrLoja) "
                . "VALUES ( "
                . "$user, "
                . "(SELECT idTipoPagLoja FROM tipopag_loja where idLoja=$idLoja LIMIT 1), "
                . "(SELECT idTaxa FROM tipoentr_loja where idLoja=$idLoja limit 1), "
                . "$morada, "
                . "$codpostal, "
                . "(SELECT idTipoEntrLoja FROM tipoentr_loja where idLoja=$idLoja limit 1)"
                . ");";
        perform_query($query);
        $idEncomenda = mysql_insert_id();
        $today = date("Ymd");
        $query = "INSERT INTO estado_encomenda_data ("
                . "idEncomenda, idEstado, dataEstado) VALUES ("
                . $idEncomenda . ", 1, $today);";
        perform_query($query);
    }

//---------- Lê cookie e faz ciclo a escrever em enc_detalhe
    $carrinho = json_decode($_COOKIE["carrinho"]);
    $keys = array_keys($carrinho);
    for ($i = 0; $i < count($carrinho); $i++) {
        if ($carrinho[$keys[$i]] !== null) {
            $quant = $carrinho[$keys[$i]];
            $idProduto = $keys[$i];
            $query = "select idDetEnc from detencomenda "
                    . "where idProduto=$idProduto and idEncomenda=$idEncomenda";
            $result = perform_query($query);
            $row = mysql_fetch_array($result);

//---------- Verifica se o produto já está no carrinho (acrescenta 1 unidade)
//---------- ou não (insere o produto no carrinho)
            if ($row[0]) {
                $idDetEnc = $row[0];
                $query = "UPDATE detencomenda SET "
                        . "idEncomenda = $idEncomenda, "
                        . "idProduto = $idProduto, "
                        . "quantidade = quantidade + $quant, "
                        . "precoVenda = (select round(p.precoUnit *(1+t.valorTaxa),2) as valorVenda "
                        . "from produtos as p inner join "
                        . "taxaivaproduto as t "
                        . "on p.idTaxa=t.idTaxa where idProduto=$idProduto), "
                        . "tIva = (select t.valorTaxa as valorTaxa from produtos as p"
                        . " inner join taxaivaproduto as t "
                        . "on p.idTaxa=t.idTaxa where idProduto=$idProduto)"
                        . "WHERE idDetEnc = $idDetEnc;";
                $result = perform_query($query);
            } else {
                $query = "INSERT INTO detencomenda ("
                        . "idEncomenda, idProduto, quantidade, precoVenda, tIva"
                        . ") VALUES ("
                        . "$idEncomenda, "
                        . "$idProduto, "
                        . "$quant , "
                        . "$quant * ("
                        . "select round(p.precoUnit *(1+t.valorTaxa),2) as valorVenda "
                        . "from produtos as p inner join "
                        . "taxaivaproduto as t "
                        . "on p.idTaxa=t.idTaxa where idProduto=$idProduto), "
                        . "(select t.valorTaxa as valorTaxa from produtos as p"
                        . " inner join taxaivaproduto as t "
                        . "on p.idTaxa=t.idTaxa where idProduto=$idProduto)"
                        . ");";
                perform_query($query);
            }
        }
    }

//---------- Apagar cookie e encaminhar para o carrinho de compras
    setcookie("carrinho", null, time() - 3600, '/');
    header('Location: listaCarrinho.php', true, $statusCode);
}

/**
 * PHP
 * 
 * Selecciona os produtos que 
 * "aguardam pagamento": carrinho de compras
 *
 * @author Eduardo Fernandes
 */
function checkCarrinhoBD() {
    global $user;
    $query = "select d.*,p.*,t.valorTaxa  from detencomenda as d "
            . "inner join produtos as p "
            . "on d.idProduto = p.idProduto "
            . "inner join taxaivaproduto as t "
            . "on p.idTaxa = t.idTaxa "
            . "where d.idEncomenda="
            . "(select e.idEncomenda from encomendas as e "
            . "inner join estado_encomenda_data as ee "
            . "on e.idEncomenda = ee.idEncomenda "
            . "where e.idCliente='"
            . $user . "' and ee.idEstado=1"
            . " Limit 1);";

    $connect = ligar_base_dados();
    return perform_query($query);
}

/**
 * PHP
 * 
 * Adicionar o item ao carrinho de compras
 * na base de dados
 *
 * @author Eduardo Fernandes
 */
function addBdItem($idEncomenda, $idProduto) {
    global $user;
    global $idLoja;
    if ($idEncomenda === null) {

//---------- Carrega dados do cliente
        $query = "SELECT c.*, cp.local "
                . "FROM clientes as c "
                . "inner join codigos_postais as cp "
                . "on c.codPostal = cp.codPostal "
                . "where idCliente='" . $user . "';";
        $results_cliente = perform_query($query);
        $row_cliente = mysql_fetch_array($results_cliente);
        $codpostal = $row_cliente[7];
        $morada = $row_cliente[6];

//---------- Insere nova encomenda
        $query = "INSERT INTO encomendas("
                . "idCliente,idTipoPagLoja, "
                . "txIvaEntr, "
                . "moradaEntrega, codpostal, "
                . "tipoentr_loja_idTipoEntrLoja) "
                . "VALUES ( "
                . "$user, "
                . "(SELECT idTipoPagLoja FROM tipopag_loja where idLoja=$idLoja LIMIT 1), "
                . "(SELECT idTaxa FROM tipoentr_loja where idLoja=$idLoja limit 1), "
                . "$morada, "
                . "$codpostal, "
                . "(SELECT idTipoEntrLoja FROM tipoentr_loja where idLoja=$idLoja limit 1)"
                . ");";
        perform_query($query);
        $idEncomenda = mysql_insert_id();
        $today = date("Ymd");
        $query = "INSERT INTO estado_encomenda_data ("
                . "idEncomenda, idEstado, dataEstado) VALUES ("
                . $idEncomenda . ", 1, $today);";
        perform_query($query);
    }

//---------- escrever item em enc_detalhe
    $query = "select idDetEnc from detencomenda "
            . "where idProduto=$idProduto and idEncomenda=$idEncomenda";
    $result = perform_query($query);
    $row = mysql_fetch_array($result);

//---------- Verifica se o produto já está no carrinho (acrescenta 1 unidade)
//---------- ou não (insere o produto no carrinho)
    if ($row[0]) {
        $idDetEnc = $row[0];
        $query = "UPDATE detencomenda SET "
                . "idEncomenda = $idEncomenda, "
                . "idProduto = $idProduto, "
                . "quantidade = quantidade + 1, "
                . "precoVenda = (select round(p.precoUnit *(1+t.valorTaxa),2) as valorVenda "
                . "from produtos as p inner join "
                . "taxaivaproduto as t "
                . "on p.idTaxa=t.idTaxa where idProduto=$idProduto), "
                . "tIva = (select t.valorTaxa as valorTaxa from produtos as p"
                . " inner join taxaivaproduto as t "
                . "on p.idTaxa=t.idTaxa where idProduto=$idProduto)"
                . "WHERE idDetEnc = $idDetEnc;";
        $result = perform_query($query);
    } else {
        $query = "INSERT INTO detencomenda ("
                . "idEncomenda, idProduto, quantidade, precoVenda, tIva"
                . ") VALUES ("
                . "$idEncomenda, "
                . "$idProduto, "
                . "1 , "
                . "("
                . "select round(p.precoUnit *(1+t.valorTaxa),2) as valorVenda "
                . "from produtos as p inner join "
                . "taxaivaproduto as t "
                . "on p.idTaxa=t.idTaxa where idProduto=$idProduto), "
                . "(select t.valorTaxa as valorTaxa from produtos as p"
                . " inner join taxaivaproduto as t "
                . "on p.idTaxa=t.idTaxa where idProduto=$idProduto)"
                . ");";
        perform_query($query);
    }
}
