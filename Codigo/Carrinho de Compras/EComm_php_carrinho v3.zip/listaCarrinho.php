<?php
/**
 * PHP
 *
 * Visualiza o carrinho
 * Configura a encomenda
 *
 * @author Eduardo Fernandes
 */
session_start();

include_once 'funcBase.php';
include_once 'funcoes_bd.php';

if (!isset($_SESSION['idcliente'])) {
    redirect();
} else {
    $i = 0;
    $user = $_SESSION['idcliente'];

//---------- selecciona os produtos que "aguardam pagamento": carrinho de compras
//---------- dados necessários à configuração da encomenda    
    $query = "select d.*,p.*,t.valorTaxa  from detencomenda as d "
            . "inner join produtos as p "
            . "on d.idProduto = p.idProduto "
            . "inner join taxaivaproduto as t "
            . "on p.idTaxa = t.idTaxa "
            . "where d.idEncomenda="
            . "(select e.idEncomenda from encomendas as e "
            . "inner join estado_encomenda_data as ee "
            . "on e.idEncomenda = ee.idEncomenda "
            . "where e.idCliente='"
            . $user . "' and ee.idEstado=1"
            . " Limit 1);";

    $connect = ligar_base_dados();
    $results = perform_query($query);
    $query = "SELECT c.*, cp.local "
            . "FROM clientes as c "
            . "inner join codigos_postais as cp "
            . "on c.codPostal = cp.codPostal "
            . "where idCliente='" . $user . "';";
    $results_cliente = perform_query($query);
    $query = "select * from codigos_postais";
    $results_cp = perform_query($query);
    $query = "select * from tipoPagamentos as tp "
            . "inner join tipopag_loja as tpl "
            . "on tpl.idTipoPag = tp.idtipoTipoPag "
            . "where tpl.idLoja='" . $_SESSION["idloja"] . "'";
    $results_tipopag = perform_query($query);
    $query = "select tl.*, te.*, iva.valorTaxa from tipoentr_loja as tl "
            . "inner join tiposEntrega as te "
            . "on tl.idTipoEntr = te.idTipoEntr "
            . "inner join taxaivaproduto as iva "
            . "on tl.idTaxa = iva.idTaxa "
            . "where tl.idLoja='" . $_SESSION["idloja"] . "'";
    $results_tipoentr = perform_query($query);
    $query = "SELECT * FROM codigos_postais order by codPostal ASC;";
    $results_codpostal = perform_query($query);
}
?>
<!DOCTYPE html>

<html>
    <head>
        <title><?= $_SESSION['desigcomercial'] ?> - Hosted by T1G1</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
        <!-- Optional theme -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap-theme.min.css" integrity="sha384-fLW2N01lMqjakBkx3l/M9EahuwpSfeNvV63J5ezn3uZzapT0u7EYsXMjQV+0En5r" crossorigin="anonymous">
        <!-- Latest compiled and minified JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
        <script src="/js/jquery.min.js"></script>
        <link href="css/styles.css" type="text/css" rel="stylesheet" />
        <link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css"/>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>

        <script src="js/jsform.js"></script>
    </head>

    <body >

        <form action="encomenda.php" method="POST" id="form1">
            <div style="width:90%;  margin:0 auto; ">
                <div class="container" style=" width:100%; margin:0 auto;">
                    <div class = "panel panel-info">
                        <div class = "panel-heading"> <h2 class = "panel-title">Carrinho de Compras</h2>
                        </div>
                        <div class = "panel-body">
                            <table class = "table table-hover" style="border-bottom: 1px #000 solid; border-top: 1px #000 solid">
                                <thead>
                                    <tr>
                                        <th class="col-xs-1"></th>
                                        <th class="col-xs-2">Descrição</th>
                                        <th class="col-xs-1">Quantidade</th>
                                        <th class="col-xs-1">Preço</th>
                                        <th class="col-xs-1">Sub-Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
//---------- carrega variáves resultantes da query e gera tabela de produtos
                                    if (mysql_num_rows($results) > 0) {
                                        $valorTotalComp = 0;
                                        $i = 0;
                                        while ($row = mysql_fetch_array($results)) {
                                            $i++;
                                            $idDetEnc = $row[0];
                                            $idEncomenda = $row[1];
                                            $idProduto = $row[2];
                                            $quantidade = $row[3];
                                            $precoUnit = $row[12];

                                            $tIva = $row[20];
                                            $precoVenda = round($precoUnit * (1 + $tIva), 2);

                                            $desigProduto = $row[8];
                                            $stock = $row[17];
                                            $imagem = $row[19];
                                            $subTotal = $precoVenda * $quantidade;
                                            ?>

                                        <input type="hidden"  name="idDetEnc<?= $i ?>" value="<?= $idDetEnc ?>">
                                        <input type="hidden"   name="idProduto<?= $i ?>" value="<?= $idProduto ?>">

                                        <input type="hidden"   name="quantidade<?= $i ?>" id="quantidadeForm<?= $i ?>" value="<?= $quantidade ?>">
                                        <input type="hidden"  name="precoUnit<?= $i ?>" value="<?= $precoUnit ?>">
                                        <input type="hidden"  name="tIva<?= $i ?>" value="<?= $tIva ?>">
                                        <tr>
                                            <td><a href="fichaproduto.php?idProduto=<?= $idProduto ?>"><img width="150px"  src="<?= $imagem ?>"></a>
                                            </td>
                                            <td>


                                                <span class="hid" id="idProduto<?= $i ?>"><?= $idProduto ?></span>  

                                                <span class="listaText" id="desigProduto<?= $i ?>"><?= $desigProduto ?></span>

                                            </td>
                                            <td>
                                                <span class="hid" id="stock<?= $i ?>"><?= $stock ?></span>

                                                <span class="listaText" id="quantidade<?= $i ?>"><?= $quantidade ?></span>

                                                <a class = "btn btn-default btn-xs" id="upQtdB<?= $i ?>" onclick="upQtd(<?= $i ?>);">
                                                    <span class="glyphicon glyphicon-chevron-up"></span></a>

                                                <a class = "btn btn-default btn-xs" id="downQtdB<?= $i ?>" onclick="downQtd(<?= $i ?>);">
                                                    <span class="glyphicon glyphicon-chevron-down"></span>
                                                </a>          
                                            </td>
                                            <td>
                                                <span>€ </span><span id="precoVenda<?= $i ?>" class="fa"><?= $precoVenda ?></span>

                                            </td>
                                            <td>
                                                <span>€ </span>
                                                <span class="listaText fa" id="subTotal<?= $i ?>">
                                                    <?php
                                                    $valorTotalComp+=$subTotal;
                                                    echo number_format($subTotal, 2, '.', ' ');
                                                    ?></span>

                                            </td>
                                        </tr>


                                        <?php
                                    }
                                    ?>    
                                    </tbody>
                                    <tfoot>

                                        <tr>
                                            <td colspan="3" align="left"> </td>
                                            <td colspan="3" align="right"><span class=" input-lg fa2x" >
                                                    <span>
                                                        <strong>
                                                            Total: € 
                                                            <span id="TotalProd"> 
                                                                <?= number_format($valorTotalComp, 2, '.', ' '); ?>

                                                            </span>
                                                        </strong>
                                                    </span>
                                                </span> 
                                            </td>
                                        </tr>
                                    </tfoot>

                                    <?php
                                } else {
                                    echo "<td colspan=\"6\">Não tem um carrinho ativo. <a href='produtos.php'>"
                                    . "Voltar à loja.</a></td></div>";
                                }
                                ?>

                            </table>
                            <input type="hidden"  name="valorTotalComp" id="valorTotalCompForm" value="<?= $valorTotalComp ?>">
                            <input type="hidden"  name="num"   value="<?= $i ?>">
                            <input type="hidden"   name="idEncomenda" value="<?= $idEncomenda ?>">
                        </div>
                    </div>
                </div>
                <p></p><p></p>

                <div class="container" style=" width:50%; float:left;">
                    <div class = "panel panel-info"  style="height: 400px">
                        <div class = "panel-heading"> <h2 class = "panel-title">Morada de Envio:</h2></div>
                        <div class = "panel-body">
                            <br><br>
                            <?php
//---------- Configuração da morada de envio da encomenda
                            if (mysql_num_rows($results_cliente) > 0) {

                                while ($row = mysql_fetch_array($results_cliente)) {

                                    print $row[2] . "<br>";
                                    print $row[6] . "<br><br>";
                                    print $row[7] . "  ";
                                    print $row[10] . "<br><br>";
                                    $moradaCli = $row[6];
                                    $codPostalCli = $row[7];
                                }
                            }
                            ?>
                        </div>
                    </div>
                </div>
                <div class="container" style=" width:50%; float:right;">
                    <div class = "panel panel-info" style="height: 400px">
                        <div class = "panel-heading"> <h2 class = "panel-title">Alterar Morada de Envio:</h2>
                        </div>
                        <div class = "panel-body">
                            <label for="novaMorada">Se desejar enviar a sua encomenda para uma morada direfente, <br>
                                por favor indique-a na caixa abaixo. Tenha o cuidado de escrever a morada completa e escolha o código postal da lista abaixo:</label>
                            <div>
                                <textarea name="novaMorada" id="novaMorada" rows="10" style="width:100%"><?= $moradaCli ?></textarea>
                            </div>


                            <select name="codpost">
                                <?php
                                if (mysql_num_rows($results_codpostal) > 0) {

                                    while ($row = mysql_fetch_array($results_codpostal)) {
                                        ?>

                                        <option value="<?= $row[0] ?>" <?php
                                        if ($row[0] == $codPostalCli) {
                                            echo 'selected';
                                        };
                                        ?>><?= $row[0] ?>  <?= $row[1] ?></option>;

                                        <?php
                                    }
                                }
                                ?>        
                            </select>
                            <p></p>  </div>

                    </div>       
                </div>      




                <div class="container" style=" width:50%; float:left; margin:0 auto;">
                    <div class = "panel panel-info" style="height: 200px">
                        <div class = "panel-heading"> <h2 class = "panel-title">Escolha como quer receber a sua encomenda:</h2>
                        </div>
                        <div class = "panel-body">
                            <p></p>
                            <select name="tipoentrega">
                                <?php
//---------- Configurar o tipo de entrega
                                if (mysql_num_rows($results_tipoentr) > 0) {
                                    while ($row = mysql_fetch_array($results_tipoentr)) {
                                        ?>
                                        <option value="<?= $row[0] ?>|<?= $row[0] ?>|<?= round(($row[1] * (1 + $row[8])), 2) ?>"><?= $row[7] ?>  (+ € <?= number_format(round(($row[1] * (1 + $row[8])), 2), 2, '.', ' ') ?>)</option>;         
                                        <?php
                                    }
                                }
                                ?>
                            </select>
                            <p></p>
                        </div>
                    </div>

                </div>
                <div class="container" style=" width:50%; float:right; margin:0 auto;">
                    <div class = "panel panel-info"  style="height: 200px">
                        <div class = "panel-heading"> <h2 class = "panel-title">Escolha o seu método de pagamento preferido:</h2>
                        </div>
                        <div class = "panel-body">

                            <?php
//---------- Configurar o método de pagamento
                            if (mysql_num_rows($results_tipopag) > 0) {
                                $j = 0;
                                while ($row = mysql_fetch_array($results_tipopag)) {
                                    $j++;
                                    ?>
                                    <input type="radio" name="tipopagamento" id="idtipopag<?= $j ?>" value="<?= $row[0] ?>" checked="checked"><label for="idtipopag<?= $j ?>"><?= $row[2] ?></label><br>
                                    <?php
                                }
                            }
                            ?>
                            <p></p>
                        </div>
                    </div>
                </div>
                <p></p><p style="text-align: center"><a class="btn btn-success" id="btEfinal" onCLick="finalizarEnc();">Encomendar</a></p>
            </div>
        </form>
        <script>

            /**
             * Javascript
             * 
             * Envia dados da encomenda por POST (com quantidades retificadas)
             *
             * @author Eduardo Fernandes
             */
            function finalizarEnc()
            {
                var vTot = document.getElementById("TotalProd").innerHTML;
                if (vTot == 0)
                {
                    alert("O seu carrinho está vazio!");
                } else
                {
                    vTot.replace(" ", "");
                    document.getElementById("valorTotalCompForm").value = parseFloat(vTot + 0);
                    document.getElementById("form1").submit();
                }
            }


            /**
             * Javascript
             * 
             * Atualiza a quantidade (mais) e verifica se há stock disponível
             * id identificação do produto que foi alterado
             *
             * @author Eduardo Fernandes
             */
            function upQtd(id)
            {
                var objId = document.getElementById("quantidade" + id);
                var objName = document.getElementsByName("quantidade" + id);
                var qtd = parseInt(objId.innerHTML) + 1;
                var stk = document.getElementById("stock" + id);
                if (parseInt(qtd) > parseInt(stk.innerHTML))
                {
                    document.getElementById("upQtdB" + id).title = "não há stock disponível no momento.";
                    document.getElementById("upQtdB" + id).disabled = true;
                } else {
                    objId.innerHTML = qtd;
                    objName.innerHTML = qtd;
                    var prc = parseFloat(document.getElementById("precoVenda" + id).innerHTML);
                    var objStId = document.getElementById("subTotal" + id);
                    objStId.innerHTML = currencyFormatPT(prc + parseFloat(objStId.innerHTML.replace(" ", "")));
                    TotalProd.innerHTML = currencyFormatPT(prc + parseFloat(TotalProd.innerHTML.replace(" ", "")));
                }
            }


            /**
             * Javascript
             * 
             * Atualiza a quantidade (menos)
             * id identificação do produto que foi alterado
             *
             * @author Eduardo Fernandes
             */
            function downQtd(id)
            {
                var objId = document.getElementById("quantidade" + id);
                document.getElementById("upQtdB" + id).disabled = false;
                var qtd = parseInt(objId.innerHTML);
                if (qtd - 1 >= 0)
                {
                    qtd--;
                    objId.innerHTML = qtd;
                    var prc = parseFloat(document.getElementById("precoVenda" + id).innerHTML);
                    var objStId = document.getElementById("subTotal" + id);
                    objStId.innerHTML = currencyFormatPT(parseFloat(objStId.innerHTML.replace(" ", "")) - prc);
                    TotalProd.innerHTML = currencyFormatPT(parseFloat(TotalProd.innerHTML.replace(" ", "")) - prc);
                }
            }

        </script>



    </body>

</html>