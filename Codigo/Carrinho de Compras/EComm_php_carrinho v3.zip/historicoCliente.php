<?php
/**
 * PHP
 *
 * Histórico de compras do cliente (front-office)
 *
 * @author Eduardo Fernandes
 */
session_start();

include_once 'funcBase.php';
include_once 'funcoes_bd.php';

if (!isset($_SESSION['idcliente'])) {
    redirect();
} else {

//---------- Cancela a encomenda
    if (isset($_GET["c"])) {
        $query = "INSERT INTO estado_encomenda_data ( "
                . "idEncomenda, idEstado, dataEstado) "
                . "VALUES " . $_GET["c"] . ",5," . date("Ymd") . ");";
    }
    $i = 0;
    $user = $_SESSION['idcliente'];

//---------- Carrega a lista de encomendas
    $query = "select enc.*, ee.DescrEstado, eel.idEncomenda, "
            . "eel.dataEstado, eel.idEstado  from encomendas as enc "
            . "inner join estado_encomenda_data as eel  "
            . "on eel.idEncomenda = enc.idEncomenda "
            . "inner join estadosencomendas as ee "
            . "on eel.idEstado = ee.idEstado "
            . "where enc.idCliente=1 "
            . "order by eel.dataEstado DESC "
            . "Limit 1;";

    $connect = ligar_base_dados();
    $results_hist = perform_query($query);
}
?>
<!DOCTYPE html>

<html>
    <head>
        <title><?= $_SESSION['desigcomercial'] ?> - Hosted by T1G1</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
        <!-- Optional theme -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap-theme.min.css" integrity="sha384-fLW2N01lMqjakBkx3l/M9EahuwpSfeNvV63J5ezn3uZzapT0u7EYsXMjQV+0En5r" crossorigin="anonymous">
        <!-- Latest compiled and minified JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
        <script src="/js/jquery.min.js"></script>
        <link href="css/styles.css" type="text/css" rel="stylesheet" />
        <link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css"/>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
        <script>



            /**
             * Javascript
             * 
             * Carrega o detalhe da encomenda
             * Usa ajax
             * adaptado de www.w3schools.com
             *
             * @author Eduardo Fernandes
             */
            function showDet(str) {
                if (str == "") {
                    document.getElementById("txtHint" + str).innerHTML = "";
                    return;
                } else {
                    if (window.XMLHttpRequest) {
                        // code for IE7+, Firefox, Chrome, Opera, Safari
                        xmlhttp = new XMLHttpRequest();
                    } else {
                        // code for IE6, IE5
                        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                    }
                    xmlhttp.onreadystatechange = function () {
                        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                            document.getElementById("txtHint" + str).innerHTML = xmlhttp.responseText;
                        }
                    };
                    xmlhttp.open("GET", "getEncDetalhe.php?q=" + str, true);
                    xmlhttp.send();
                }
            }
        </script>
        <script src="js/jsform.js"></script>
    </head>

    <body >

        <div style="width:90%;  margin:0 auto; ">
            <div class="container" style=" width:100%; margin:0 auto;">
                <div class = "panel panel-info">
                    <div class = "panel-heading"> <h2 class = "panel-title">Histórico de Compras</h2>
                    </div>
                    <div class = "panel-body">
                        <table class = "table table-hover" style="border-bottom: 1px #000 solid; border-top: 1px #000 solid">
                            <thead>
                                <tr>
                                    <th class="col-xs-1"></th>
                                    <th class="col-xs-2">Estado</th>
                                    <th class="col-xs-1">Data</th>
                                    <th class="col-xs-1">Valor</th>
                                    <th class="col-xs-1">Código do Despacho</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                if (mysql_num_rows($results_hist) > 0) {

                                    $i = 0;
                                    while ($row = mysql_fetch_array($results_hist)) {
                                        $i++;
                                        $dataEstado = date_create($row[14]);
                                        $idEncomenda = $row[0];
                                        $custoEntrega = $row[4];
                                        $valorTotal = $row[7];
                                        $estado = $row[12];
                                        $idEstado = $row[15];
                                        $codDespacho = $row[5];
                                        if ($idEstado == 2 || $idEstado == 3) {

//---------- disponibiliza a função de cancelamento se a encomenda não tiver sido expedida
                                            $message = '<a href="#" data-toggle="tooltip" title="Cancelar a encomenda"  data-placement="right" class="btn btn-xs btn-danger" onclick="cancelEnc(' . $idEncomenda . ')"><span class="glyphicon glyphicon-fire"></span></a>';
                                        } else {
                                            $message = '';
                                        }
                                        ?>
                                        <tr  class="accordion-toggle" >

                                            <td>
                                                <a  data-toggle="collapse" class="btn btn-xs btn-primary" onmousedown="showDet(<?= $idEncomenda ?>)">Ver detalhes <span class="glyphicon glyphicon-folder-open"></span></a> <?= $message ?> 
                                            </td>
                                            <td>
                                                <input type="hidden"  name="idEncomenda<?= $i ?>" value="<?= $idEncomenda ?>">
                                                <span class="listaText" id="estado<?= $i ?>"><?= $estado ?></span>
                                            </td>
                                            <td>
                                                <span class="listaText" id="dataEstado<?= $i ?>"><?= date_format($dataEstado, 'Y-m-d'); ?></span>


                                            </td>
                                            <td>
                                                <span>€ </span><span id="valorTotal<?= $i ?>" class="fa"><?= $valorTotal ?></span>

                                            </td>
                                            <td>
                                                <div class="listaText" id="codDespacho<?= $i ?>"><?= $codDespacho ?></div>
                                            </td>

                                        </tr>                     
                                        <tr class="hiddenRow" id="id<?= $i ?>">
                                            <td colspan="5" id="txtHint<?= $i ?>"></td>

                                        </tr>
                                        <?php
                                    }
                                    ?>    
                                </tbody>


                                <?php
                            } else {
                                echo "<td colspan=\"6\">Ainda não comprou nada aqui. Do que está à espera? <a href='produtos.php'>"
                                . "Voltar à loja.</a></td></div>";
                            }
                            ?>

                        </table>
                    </div>
                </div>
            </div>
            <script>
                /**
                 * Javascript
                 * 
                 * Chama a rotina para cancelar a encomenda
                 *
                 * @author Eduardo Fernandes
                 */
                function cancelEnc(id)
                {
                    var str = prompt("Para confirmar o cancelamento da sua encomenda, por favor insira a palavra \"cancelar\" na caixa abaixo:");
                    if (str == "cancelar") {
                        window.location.href = "historicoCliente.php?c=" + id;
                    } else {
                        alert("NÃO cancelado");
                    }

                }
            </script>
    </body>

</html>