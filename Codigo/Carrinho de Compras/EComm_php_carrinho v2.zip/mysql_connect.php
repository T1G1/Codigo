<?php
    define('MYSQL_SERVER', '127.0.0.1:3306');    
    define('MYSQL_USERNAME', 'root');
    define('MYSQL_PASSWORD', 'qualificait1');       
    define('MYSQL_DATABASE', 't1g1');
?>
