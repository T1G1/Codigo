<?php

include_once 'funcoes_bd.php';

session_start();


$username =$_POST['username'];
$password =$_POST['password'];


if (isset($_GET['logout']) || isset($_POST['canc'])) {
    session_destroy();
    header("Location: index.php");
} 

else {
    
  if ($username && !$password) {
      
      echo '<script language="javascript">';
      echo 'alert("Por favor insira uma password.");';
      echo 'window.location= "index.php";';
      echo '</script>';
  }
  
  else if (!$username) {
      
      echo '<script language="javascript">';
      echo 'alert("Por favor insira um nome de utilizador.");';
      echo 'window.location= "index.php";';
      echo '</script>';
      
  }
  
  else if ($username && $password)
  {
    
    $connect = ligar_base_dados();

    $query = ("SELECT u.*, c.idCliente,l.desigComercial FROM utilizadores as u "
            . "inner join clientes as c "
            . "on u.idUtilizador = c.idUtilizador "
            . "inner join loja as l "
            . "on l.idLoja = u.idLoja "
            . "WHERE userName='$username'");
echo $query;
    $numrows = mysql_query($query, $connect);
 
    if (mysql_num_rows($numrows) > 0) {
        
        while ($dados =  mysql_fetch_assoc($numrows)) {
            
           $dbusername = $dados['userName'];
           $dbpassword = $dados['password'];
           $dbidloja = $dados['idLoja'];
           $dbidCliente = $dados['idCliente'];
           $tipo = $dados['idTipoUt'];
           $dbdesigComercial = $dados['desigComercial'];
           
        }
        
        if($username==$dbusername&&$password==$dbpassword) {
            
            $_SESSION['username']=$username;
            $_SESSION['password'] = $password;
            $_SESSION['tipo'] = $tipo;
            $_SESSION['idcliente'] = $dbidCliente;
            $_SESSION['idloja'] = $dbidloja;
            $_SESSION['desigcomercial'] = $dbdesigComercial;
            header("Location: index.php");
            
            
        }
        else {
            echo '<script language="javascript">';
            echo 'alert("Password errada.");';
            echo 'window.location= "index.php";';
            echo '</script>';
        }
    } 
    
    else {
        echo '<script language="javascript">';
        echo 'alert("Utilizador não existe.");';
        echo 'window.location= "index.php";';
        echo '</script>';     
    }
    
    
} 
 

}


?>
 