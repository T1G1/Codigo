<?php
session_start();
?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <form action="login.php" method="POST">
            <input type="text" name="username" value="carlaasilva@sapo.pt">
            <input type="text" name="password">
            <input type="submit">
        </form>
        <?php
        if(isset($_SESSION['username']))
            {
            if($_SESSION['tipo']==1)
                {
                    echo '<p><a href="listaCarrinho.php">Ir para o carrinho de compras</a></p>';
                    echo '<p><a href="historicoCliente.php">Ir para o histórico de compras</a></p>';
                    
                }
            }
    ?>
                </body>
</html>
