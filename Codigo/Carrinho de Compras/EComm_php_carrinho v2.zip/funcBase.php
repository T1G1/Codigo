<?php
function perform_query($query) {
  $db = mysql_connect("localhost", "root", "qualificait1")
    or die("Could not connect to database: " . mysql_error());
  mysql_select_db("t1g1")
    or die("Could not select database" . mysql_error());
  $results = mysql_query($query)
    or die("Query (" . $query . ") failed" . mysql_error());
   mysql_close($db);
  return $results;
}

function redirect($statusCode = 303)
{
   header('Location: index.php', true, $statusCode);
   die();
}

function GET($name=NULL, $value=false, $option="default")
{
    $option=false; // Old version depricated part
    $content=(!empty($_GET[$name]) ? trim($_GET[$name]) : (!empty($value) && !is_array($value) ? trim($value) : false));
    if(is_numeric($content))
        return preg_replace("@([^0-9])@Ui", "", $content);
    else if(is_bool($content))
        return ($content?true:false);
    else if(is_float($content))
        return preg_replace("@([^0-9\,\.\+\-])@Ui", "", $content);
    else if(is_string($content))
    {
        if(filter_var ($content, FILTER_VALIDATE_URL))
            return $content;
        else if(filter_var ($content, FILTER_VALIDATE_EMAIL))
            return $content;
        else if(filter_var ($content, FILTER_VALIDATE_IP))
            return $content;
        else if(filter_var ($content, FILTER_VALIDATE_FLOAT))
            return $content;
        else
            return preg_replace("@([^a-zA-Z0-9\+\-\_\*\@\$\!\;\.\?\#\:\=\%\/\ ]+)@Ui", "", $content);
    }
    else false;
}

function mailEstado($subject, $to,$body,$nome)
{
$from = 'website@gcoa.com';
$headers = "From: $from";
switch ($body)
{
    case ("act"):
        $message = "<h2>Atualização do Estado da Encomenda</h2>"
            . "<p>*** Dados da Encomenda **</p>"
            . "<p>Caro(a) " . $nome . "</p>"
            . "<div><p>O estado da sua encomenda foi atualizado. "
            . "Pode consultar a alteração no seu histórico de compras. "
            . "</p></div>";
        break;
}
mail($to,$subject,$message,$headers);
}
?>


