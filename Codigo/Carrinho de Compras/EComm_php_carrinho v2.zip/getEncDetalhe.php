<?php
session_start();

include_once 'funcBase.php';
include_once 'funcoes_bd.php';

if (!isset($_SESSION['idcliente'])) {
    redirect();
} else {
    $i = 0;
    $user = $_SESSION['idcliente'];

    //selecciona o os detalhes da encomenda
    $query = "select d.*,p.*,t.valorTaxa "
            . "from detencomenda as d "
            . "inner join produtos as p "
            . "on d.idProduto = p.idProduto "
            . "inner join taxaivaproduto as t "
            . "on p.idTaxa = t.idTaxa  "
            . "where d.idEncomenda="
            . intval($_GET["q"]) . ";";

    $connect = ligar_base_dados();
    $results = perform_query($query);
   
   /* 
    $query = "SELECT c.*, cp.local "
            . "FROM clientes as c "
            . "inner join codigos_postais as cp "
            . "on c.codPostal = cp.codPostal "
            . "where idCliente='" . $user . "';";
    $results_cliente = perform_query($query);
    $query = "select * from codigos_postais";
    $results_cp = perform_query($query);
    $query = "select * from tipoPagamentos as tp "
            . "inner join tipopag_loja as tpl "
            . "on tpl.idTipoPag = tp.idtipoTipoPag "
            . "where tpl.idLoja='" . $_SESSION["idloja"] . "'";
    $results_tipopag = perform_query($query);
    $query = "select tl.*, te.*, iva.valorTaxa from tipoentr_loja as tl "
            . "inner join tiposEntrega as te "
            . "on tl.idTipoEntr = te.idTipoEntr "
            . "inner join taxaivaproduto as iva "
            . "on tl.idTaxa = iva.idTaxa "
            . "where tl.idLoja='" . $_SESSION["idloja"] . "'";
    $results_tipoentr = perform_query($query);
    $query = "SELECT * FROM codigos_postais order by codPostal ASC;";
    $results_codpostal = perform_query($query);
*/

    echo '<table class = "table table-hover" style="border-bottom: 1px #000 solid; border-top: 1px #000 solid">
            <thead>
            <tr>
            <th class="col-xs-1"></th>
            <th class="col-xs-2">Descrição</th>
            <th class="col-xs-1">Quantidade</th>
            <th class="col-xs-1">Preço</th>
            <th class="col-xs-1">Sub-Total</th>
            </tr>
            </thead>
            <tbody>';
                           
    if (mysql_num_rows($results) > 0) {
        $valorTotalComp = 0;
        $i = 0;
        while ($row = mysql_fetch_array($results)) 
        {

            $i++;
            $idDetEnc = $row[0];
            $idEncomenda = $row[1];
            $idProduto = $row[2];
            $quantidade = $row[3]; //quantidade na encomenda
            $precoUnit = $row[12];

            $tIva = $row[20];
            $precoVenda = $row[4];;

            $desigProduto = $row[8];
            $stock = $row[17];
            $imagem = $row[19];
            $subTotal = $precoVenda * $quantidade;


            echo "   <tr>"
            . "<td><a href=\"fichaproduto.php?idProduto=\$idProduto\"><img width=\"150px\"  src=\"$imagem\"></a>"
            . "</td><input type=\"hidden\"  name=\"idDetEnc$i\" value=\"$idDetEnc\">"
            .   "<input type=\"hidden\"   name=\"idProduto$i\" value=\"$idProduto\">"
            .     "<input type=\"hidden\"   name=\"quantidade$i\" id=\"quantidadeForm$i\" value=\"$quantidade\">"
            . "<input type=\"hidden\"  name=\"precoUnit$i\" value=\"$precoUnit\">"
            .   "<input type=\"hidden\"  name=\"tIva$i\" value=\"$tIva\">"
            . "<td>"
            . "<span class=\"hid\" id=\"idProduto$i\">$idProduto</span> " 
            . "<span class=\"listaText\" id=\"desigProduto$i\">$desigProduto</span>"
            ."</td>"
            . "<td><span class=\"listaText\" id=\"quantidade$i\">$quantidade</span>"
            . "</td>"
            . "<td>"
            . "<span>€ </span><span id=\"precoVenda$i\" class=\"fa\">$precoVenda</span>"
            . "</td>"
            . "<td>"
            . "<span>€ </span>"
            . "<span class=\"listaText fa\" id=\"subTotal$i\">";
            echo number_format($subTotal, 2, '.', ' ');
            echo "</span></td></tr>";
        }
            echo "</tbody></table>";                   
    }                  
}                      
       ?>            
          