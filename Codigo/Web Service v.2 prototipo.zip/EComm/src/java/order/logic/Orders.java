/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package order.logic;

 
import bd.Bd;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.Singleton;
import javax.xml.bind.annotation.XmlRootElement;
 



/**
 *
 * @author Eduardo
 */
@Singleton
@XmlRootElement
public class Orders {
    private HashMap<Integer,Order> orderList;

    public Orders() {
        this.orderList = new HashMap();
    }

    public HashMap<Integer,Order> getOrderList() {
        return orderList;
    }

    public void setOrderList(HashMap<Integer,Order> orders) {
        this.orderList=orders;
    }
     
     public Collection<Order> getEncomendasCliente(Integer idCliente)
     {
      try {
            Bd bd=new Bd();
            String query="select * from encomendas where idCliente='"+idCliente+"';";
            System.out.println("[DEBUG]1: ." + query);   
            ResultSet result=bd.queryBd(query);
            while(result.next())
            {
                Integer idEncomenda=result.getInt("idEncomenda");
                //Integer idCliente=result.getInt("clientes_idCliente");
                //Integer idEstado=result.getInt("idEstado");
                Integer idTipoEntrega=result.getInt("idTipoEnt");
                Float custoEntrega=result.getFloat("custoEntrega");
                Float valorTotal=result.getFloat("valorTotal");
                Float txIvaEntr=result.getFloat("txIvaEntr");
                String idTipoPagamento=result.getString("idTipoPagamento");
                Integer codPagamento=result.getInt("codPagamento");
                Integer codDespacho=result.getInt("codDespacho");
                String moradaEntrega=result.getString("moradaEntrega");
                String codPostal=result.getString("codpostal");
                String obs=result.getString("observacoes");
                Order o = new Order(idEncomenda, idCliente, idTipoEntrega, custoEntrega, txIvaEntr,valorTotal, idTipoPagamento, codPagamento, codDespacho, moradaEntrega, codPostal, obs);
                this.orderList.put(idEncomenda,o);
                System.out.println("[DEBUG]: Carregou uma linha." + result.getString("idEncomenda")); 
                return this.orderList.values();
            }
            result.close(); 
            bd.closeBD();
 
        } catch (SQLException ex) {
            Logger.getLogger(Orders.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
     }
    public Collection<Order> getBdOrderList()
    {
        try {
            Bd bd=new Bd();
            String query="select * from encomendas;";
            System.out.println("[DEBUG]1: ." + query);   
            ResultSet result=bd.queryBd(query);
            while(result.next())
            {
                Integer idEncomenda=result.getInt("idEncomenda");
                Integer idCliente=result.getInt("idCliente");
                //Integer idEstado=result.getInt("idEstado");
                Integer idTipoEntrega=result.getInt("idTipoEnt");
                Float custoEntrega=result.getFloat("custoEntrega");
                Float valorTotal=result.getFloat("valorTotal");
                Float txIvaEntr=result.getFloat("txIvaEntr");
                String idTipoPagamento=result.getString("idTipoPagamento");
                Integer codPagamento=result.getInt("codPagamento");
                Integer codDespacho=result.getInt("codDespacho");
                String moradaEntrega=result.getString("moradaEntrega");
                String codPostal=result.getString("codpostal");
                String obs=result.getString("observacoes");
                Order o = new Order(idEncomenda, idCliente, idTipoEntrega, custoEntrega,txIvaEntr, valorTotal, idTipoPagamento, codPagamento, codDespacho, moradaEntrega, codPostal, obs);
                this.orderList.put(idEncomenda,o);
                System.out.println("[DEBUG]: Carregou uma linha." + result.getString("idEncomenda")); 
                return this.orderList.values();
            }
            result.close(); 
            bd.closeBD();
 
        } catch (SQLException ex) {
            Logger.getLogger(Orders.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    public void getOrder(Integer idEncomenda)
     {
      try {
            Bd bd=new Bd();
            String query="select * from encomendas where idEncomenda='"+idEncomenda+"';";
            System.out.println("[DEBUG]1: ." + query);   
            ResultSet result=bd.queryBd(query);
            while(result.next())
            {
                //Integer idEncomenda=result.getInt("idEncomenda");
                Integer idCliente=result.getInt("idCliente");
                //Integer idEstado=result.getInt("idEstado");
                Integer idTipoEntrega=result.getInt("idTipoEnt");
                Float custoEntrega=result.getFloat("custoEntrega");
                Float valorTotal=result.getFloat("valorTotal");
                Float txIvaEntr=result.getFloat("txIvaEntr");
                String idTipoPagamento=result.getString("idTipoPagamento");
                Integer codPagamento=result.getInt("codPagamento");
                Integer codDespacho=result.getInt("codDespacho");
                String moradaEntrega=result.getString("moradaEntrega");
                String codPostal=result.getString("codpostal");
                String obs=result.getString("observacoes");
                Order o = new Order(idEncomenda, idCliente, idTipoEntrega, custoEntrega, txIvaEntr, valorTotal, idTipoPagamento, codPagamento, codDespacho, moradaEntrega, codPostal, obs);
                this.orderList.put(idEncomenda,o);
                System.out.println("[DEBUG]: Carregou uma linha." + result.getString("idEncomenda"));          
            }
            result.close(); 
            bd.closeBD();
 
        } catch (SQLException ex) {
            Logger.getLogger(Orders.class.getName()).log(Level.SEVERE, null, ex);
        }
        
     }
    public Integer setOrder(Order order)
    {
    try {
         System.out.println("[DEBUG]: Vou tentar adicionar uma linha." );   
                Integer idCliente=order.getIdCliente();
                String morada=order.getMoradaEntrega();
                Float txIvaEntr=order.getTxIvaEntr();
                Integer idTipoEntrega=order.getIdTipoEntrega();
                Float custoEntrega=order.getCustoEntrega();
                Float valorTotal=order.getValorTotal();
                String idTipoPagamento=order.getIdTipoPagamento();
                Integer codPagamento=order.getCodPagamento();
                Integer codDespacho=order.getCodDespacho(); 
                String codPostal=order.getCodPostal();
                String obs=order.getObs(); 
                String query="INSERT INTO encomendas(clientes_idCliente,"
                            + "tiposEntrega_idTipoEnt,custoEntrega,txIvaEntr,valorTotal,"
                            + "tipopagamentos_idTipoPagamento,codPagamento,codDespacho,"
                            + "moradaEntrega,codigos_postais_codpostal,observacoes)"
                            + "VALUES('"+idCliente+"','"
                            + "'"+idTipoEntrega+"','"+custoEntrega+"',"+txIvaEntr+"',"
                            + "'"+valorTotal+"','"+idTipoPagamento+"',"
                            + "'"+codPagamento+"','"+codDespacho+"','"+morada+"',"
                            + "'"+codPostal+"','"+obs+"');";
                Bd bd=new Bd(); 
                bd.updateBd(query);   
                       System.out.println("[DEBUG]: Adicionou uma linha." );   
                bd.closeBD();  
        } catch (SQLException ex) {
            Logger.getLogger(Orders.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    return 0;
    }
    
}
