/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package order.logic;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Eduardo
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class Order {
    private Integer idEncomenda;
    private Integer idCliente;
  //  private Integer idEstado;
    private Integer idTipoEntrega;
    private Float custoEntrega;
    private Float txIvaEntr;
    private Float valorTotal;
    private String idTipoPagamento;
    private Integer codPagamento;
    private Integer codDespacho;
    private String moradaEntrega;
    private String codPostal;
    private String obs;

    public Order() {
    }
   
    public Order(Integer idEncomenda, Integer idCliente, Integer idTipoEntrega, Float custoEntrega, Float txIvaEntr, Float valorTotal, String idTipoPagamento, Integer codPagamento, Integer codDespacho, String moradaEntrega, String codPostal, String obs) {
        this.idEncomenda = idEncomenda;
        this.idCliente = idCliente;
        //this.idEstado = idEstado;
        this.idTipoEntrega = idTipoEntrega;
        this.custoEntrega = custoEntrega;
        this.txIvaEntr=txIvaEntr;
        this.valorTotal = valorTotal;
        this.idTipoPagamento = idTipoPagamento;
        this.codPagamento = codPagamento;
        this.codDespacho = codDespacho;
        this.moradaEntrega = moradaEntrega;
        this.codPostal = codPostal;
        this.obs = obs;
    }

    public Order(Integer idCliente, Integer idTipoEntrega, Float custoEntrega, Float txIvaEntr, Float valorTotal, String idTipoPagamento, Integer codPagamento, Integer codDespacho, String moradaEntrega, String codPostal, String obs) {
        this.idCliente = idCliente;
        //this.idEstado = idEstado;
        this.idTipoEntrega = idTipoEntrega;
        this.custoEntrega = custoEntrega;
        this.txIvaEntr=txIvaEntr;
        this.valorTotal = valorTotal;
        this.idTipoPagamento = idTipoPagamento;
        this.codPagamento = codPagamento;
        this.codDespacho = codDespacho;
        this.moradaEntrega = moradaEntrega;
        this.codPostal = codPostal;
        this.obs = obs;
    }
    

    public Integer getIdCliente() {
        return idCliente;
    }
 
    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public Float getTxIvaEntr() {
        return txIvaEntr;
    }

    public void setTxIvaEntr(Float txIvaEntr) {
        this.txIvaEntr = txIvaEntr;
    }

//    public Integer getIdEstado() {
//        return idEstado;
//    }
// 
//    public void setIdEstado(int idEstado) {
//        this.idEstado = idEstado;
//    }

    public Integer getIdTipoEntrega() {
        return idTipoEntrega;
    }
 
    public void setIdTipoEntrega(int idTipoEntrega) {
        this.idTipoEntrega = idTipoEntrega;
    }

    public Float getCustoEntrega() {
        return custoEntrega;
    }
 
    public void setCustoEntrega(float custoEntrega) {
        this.custoEntrega = custoEntrega;
    }

    public Float getValorTotal() {
        return valorTotal;
    }
 
    public void setValorTotal(float valorTotal) {
        this.valorTotal = valorTotal;
    }

    public String getIdTipoPagamento() {
        return idTipoPagamento;
    }
 
    public void setIdTipoPagamento(String idTipoPagamento) {
        this.idTipoPagamento = idTipoPagamento;
    }

    public Integer getCodPagamento() {
        return codPagamento;
    }
 
    public void setCodPagamento(int codPagamento) {
        this.codPagamento = codPagamento;
    }

    public Integer getCodDespacho() {
        return codDespacho;
    }
 
    public void setCodDespacho(int codDespacho) {
        this.codDespacho = codDespacho;
    }

    public String getMoradaEntrega() {
        return moradaEntrega;
    }
 
    public void setMoradaEntrega(String moradaEntrega) {
        this.moradaEntrega = moradaEntrega;
    }

    public String getCodPostal() {
        return codPostal;
    }
 
    public void setCodPostal(String codPostal) {
        this.codPostal = codPostal;
    }

    public String getObs() {
        return obs;
    }
 
    public void setObs(String obs) {
        this.obs = obs;
    }
    
     
    
}


