/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package order.logic;

import java.util.Collection;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;

/**
 * REST Web Service
 *
 * @author Eduardo
 */
@Path("orders")
public class OrdersWs {

    @Context
    private UriInfo context;
    private  final order.logic.Orders orderList= new order.logic.Orders();
    /**
     * Creates a new instance of Order
     */
    public OrdersWs() {
    }

    /**
     * Retrieves representation of an instance of order.Orders
     * @return an instance of java.lang.String
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Collection<Order> getJson() {
        //lista de todas as encomendas
         System.out.println("[DEBUG]:" + orderList.toString()); 
       return orderList.getBdOrderList();
    }

    /**
     * PUT method for updating or creating an instance of Orders
     * @param idCliente
     * @param moradaEntrega
     * @param idEstado
     * @param idTipoEntrega
     * @param custoEntrega
     * @param valorTotal
     * @param idTipoPagamento
     * @param codPagamento
     * @param codDespacho
     * @param codPostal
     * @param observacoes
     * @param servletResponse
     * @throws java.io.IOException
     */
    @POST
    //@Consumes( MediaType.APPLICATION_FORM_URLENCODED)
    @Consumes(MediaType.APPLICATION_JSON)
    public void postOrder(order.logic.Order order)
//            @FormParam("idCliente") String idCliente,
//            @FormParam("moradaEntrega") String moradaEntrega,
//            @FormParam("idEstado") String idEstado,
//            @FormParam("idTipoEntrega") String idTipoEntrega,
//            @FormParam("custoEntrega") String custoEntrega,
//            @FormParam("valorTotal") String valorTotal,
//            @FormParam("idTipoPagamento") String idTipoPagamento,
//            @FormParam("codPagamento") String codPagamento,
//            @FormParam("codDespacho") String codDespacho,
//            @FormParam("codPostal") String codPostal,
//            @FormParam("observacoes") String observacoes,
//            @Context HttpServletResponse servletResponse) throws IOException 
    {
        
        
//     order.logic.Orders order = new order.logic.Orders(
//                            Integer.parseInt(idCliente),  
//                            Integer.parseInt(idEstado), 
//                            Integer.parseInt(idTipoEntrega),  
//                            Float.parseFloat(custoEntrega),
//                            Float.parseFloat(valorTotal),  
//                            idTipoPagamento,  
//                            Integer.parseInt(codPagamento),  
//                            Integer.parseInt(codDespacho), 
//                            moradaEntrega,  
//                            codPostal,  
//                            observacoes );
     
      int result = orderList.setOrder(order);
      if(result == 0){
         //return SUCCESS_RESULT;
      }
     // return FAILURE_RESULT;
      
    }
    
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/customer/{idCliente}")
     public Collection<Order> getOrdersCustomer(@PathParam("idCliente") int num)
     {
         return orderList.getEncomendasCliente(num);
         //return orderList;
     }
     
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Path("/{idEncomenda}")
     public order.logic.Orders getOrder(@PathParam("idEncomenda") int num)
     {
         orderList.getOrder(num);
         return orderList;
     }
}
