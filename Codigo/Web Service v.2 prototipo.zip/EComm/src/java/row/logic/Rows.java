/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package row.logic;

import bd.Bd;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Eduardo
 */
public class Rows {
    private HashMap<Integer,Row> rowList;

    public Rows() {
    }
    
     public void getRows(Integer idLoja)
    {
         try {
            Bd bd=new Bd();
            String query="select * from corredor where idLoja='"+idLoja+"';";
            System.out.println("[DEBUG]1: ." + query);   
            ResultSet result=bd.queryBd(query);
            while(result.next())
            {
                Integer idCorredor=result.getInt("idCorredor");
                String desigCorredor=result.getString("desigCorredor");
                String descrCorredor=result.getString("descrCorredor");
                String imagem=result.getString("imagem");
                Row r = new Row(idCorredor,desigCorredor,descrCorredor,imagem,idLoja);
                this.rowList.put(idCorredor,r);
                System.out.println("[DEBUG]: Carregou uma linha." + result.getString("idRow"));          
            }
            result.close(); 
            bd.closeBD();
 
        } catch (SQLException ex) {
            Logger.getLogger(Rows.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
