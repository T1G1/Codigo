/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package product.logic;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Array;
import java.util.Collection;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

/**
 * REST Web Service
 *
 * @author Eduardo
 */
@Path("products")
public class ProductsWs {

    @Context
    private UriInfo context;
    private final Products pList= new Products();
    

    /**
     * Creates a new instance of Products
     */
    public ProductsWs() {
    }

    /**
     * Retrieves representation of an instance of products.ProductsWs
     * @param idStore
     * @return an instance of java.lang.String
     * Responde uma lista de todos os produtos 
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Collection<Product> getProducts(@QueryParam("idStore") Integer idStore) {
        //lista de todas as encomendas
       // if(idStore==0) return Response.status(Response.Status.BAD_REQUEST).build();
        
         return pList.getBdProductList(idStore);
        // return Response.ok(pList.getBdProductList(idStore)).build();
         //return Response.ok(objeto).build();
       //return pList;
    }
    
    @Path("{idProduct}")
    @GET
   // @Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
    @Produces(MediaType.APPLICATION_JSON)
    //@Consumes(MediaType.APPLICATION_JSON)
     public Product getProduct(@PathParam("idProduct") int idProduct)
     {
        
        // productList.addProduct(productList.getProduto(num));
         return pList.getProduct(idProduct);
          //return productList ;
     }

    /**
     * PUT method for updating  an instance of ProductsWs
     * @param prod representação do objeto Produto em JSON
     */
    
    @PUT
    @Path("{idProduct}")
    @Consumes(MediaType.APPLICATION_JSON)
    //public void putJson(InputStream input) {
      public void putJson (Product prod){
          System.out.println("[DEBUG]: PUT ws  " +prod);
        pList.putProduct(prod);
//        StringBuilder jsonBuilder = new StringBuilder();
//        try {
//            BufferedReader in = new BufferedReader(new InputStreamReader(input));
//            String line = null;
//            while((line=in.readLine())!=null)
//                    {
//                        jsonBuilder.append(line);
//                    }
//        } catch (Exception e)
//        {System.out.println("Erro");}
//        System.out.println("Recebido: " + jsonBuilder.toString());
//                
        
    }
}
