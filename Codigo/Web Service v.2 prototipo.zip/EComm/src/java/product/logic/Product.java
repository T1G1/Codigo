/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package product.logic;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 *
 * @author Eduardo
 */
@XmlRootElement
public class Product {   
    private Integer idProduto;
    private String desigProduto;
    private Integer idMarca;
    private String modelo;
    private String informacaoProduto;
    private Float precoUnit;
    private String idTaxa;
    private String unid1;
    private Float taxaConvercao;
    private String unid2;
    private Float stockActual;
    private Float stockMinimo;
    private String  imagemPesquisa;
    private Integer idPrateleira;


    public Product() {
    }

    public Product(Integer idProduto, String desigProduto, Integer idMarca, String modelo, String informacaoProduto, Float precoUnit, String idTaxa, String unid1, Float taxaconvercao, String unid2, Float stockActual, Float stockMinimo, String imagemPesquisa, Integer idPrateleira) {
        this.idProduto = idProduto;
        this.desigProduto = desigProduto;
        this.idMarca = idMarca;
        this.modelo = modelo;
        this.informacaoProduto = informacaoProduto;
        this.precoUnit = precoUnit;
        this.idTaxa = idTaxa;
        this.unid1 = unid1;
        this.taxaConvercao = taxaconvercao;
        this.unid2 = unid2;
        this.stockActual = stockActual;
        this.stockMinimo = stockMinimo;
        this.imagemPesquisa = imagemPesquisa;
        this.idPrateleira = idPrateleira;
    }

    public Product(String desigProduto, Integer idMarca, String modelo, String informacaoProduto, Float precoUnit, String idTaxa, String unid1, Float taxaconvercao, String unid2, Float stockActual, Float stockMinimo, String imagemPesquisa, Integer idPrateleira) {
        this.desigProduto = desigProduto;
        this.idMarca = idMarca;
        this.modelo = modelo;
        this.informacaoProduto = informacaoProduto;
        this.precoUnit = precoUnit;
        this.idTaxa = idTaxa;
        this.unid1 = unid1;
        this.taxaConvercao = taxaconvercao;
        this.unid2 = unid2;
        this.stockActual = stockActual;
        this.stockMinimo = stockMinimo;
        this.imagemPesquisa = imagemPesquisa;
        this.idPrateleira = idPrateleira;
    }


    
    public void setIdProduto(Integer idProduto) {
        this.idProduto = idProduto;
    }

    public Integer getIdProduto() {
        return idProduto;
    }

    
    public String getDesigProduto() {
        return desigProduto;
    }

    public void setDesigProduto(String desigProduto) {
        this.desigProduto = desigProduto;
    }

    public Integer getIdMarca() {
        return idMarca;
    }

    public void setIdMarca(Integer idMarca) {
        this.idMarca = idMarca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getInformacaoProduto() {
        return informacaoProduto;
    }

    public void setInformacaoProduto(String informacaoProduto) {
        this.informacaoProduto = informacaoProduto;
    }

    public Float getPrecoUnit() {
        return precoUnit;
    }

    public void setPrecoUnit(Float precoUnit) {
        this.precoUnit = precoUnit;
    }

    public String getIdTaxa() {
        return idTaxa;
    }

    public void setIdTaxa(String idTaxa) {
        this.idTaxa = idTaxa;
    }

    public String getUnid1() {
        return unid1;
    }

    public void setUnid1(String unid1) {
        this.unid1 = unid1;
    }

    public Float getTaxaConvercao() {
        return taxaConvercao;
    }

    public void setTaxaConvercao(Float taxaconvercao) {
        this.taxaConvercao = taxaconvercao;
    }

    public String getUnid2() {
        return unid2;
    }

    public void setUnid2(String unid2) {
        this.unid2 = unid2;
    }

    public Float getStockActual() {
        return stockActual;
    }

    public void setStockActual(Float stockActual) {
        this.stockActual = stockActual;
    }

    public Float getStockMinimo() {
        return stockMinimo;
    }

    public void setStockMinimo(Float stockMinimo) {
        this.stockMinimo = stockMinimo;
    }

    public String getImagemPesquisa() {
        return imagemPesquisa;
    }

    public void setImagemPesquisa(String imagemPesquisa) {
        this.imagemPesquisa = imagemPesquisa;
    }

    public Integer getIdPrateleira() {
        return idPrateleira;
    }

    public void setIdPrateleira(Integer idPrateleira) {
        this.idPrateleira = idPrateleira;
    }

    

   












}
