/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function actualizaTabela(dados)
{
    alert("actualizaTabela ") + dados;
  var $t=$('#tabela_encomendas tbody');
  $t.empty();
  $.each(dados,function(k,v)
  {
      alert("v: " + v);
      $('<tr></tr>')
            .append('<td>'+v.moradaEntrega+'</td>')
            .append('<td>'+v.observacoes+'</td>')
            .append('<td>'+v.valorTotal+'</td>')
            .append('<td><input type="button" value="Apaga" id="' + v.idEncomenda
                + '" onclick="apagaEncomenda(' + "'"+v.idEncomenda+"'"+')"></td>')
                .append($t);
    });
    }
  function listaEncomendas()
  {
       alert("listaEncomendas");
      $.ajax(
              {
                  url: 'http://localhost:8080/EComm/t1g1/orders',
                  type: 'GET',
                  dataType: 'JSON',
                  contentType: 'application/json; charset=utf-8',
                  success: function(data){actualizaTabela(data);},
                  error: function(err) {msgErro(JSON.stringify(err));}
                  }
            );
  }
  function msgErro(txt)
  {
      alert("msrErro ")+txt;
      $('#avisos').text(txt);
      setTimeout(function()
      {
          $('#avisos').empty();
      },3200);
      
  }
  
function insereLinhaTabela(dados)
{
    alert("insereLinhaTabela ")+dados;
    var $t=$('#tabela_encomendas tbody');
    
    $('<tr></tr>')
            .append('<td>'+v.moradaEntrega+'</td>')
            .append('<td>'+v.observacoes+'</td>')
            .append('<td>'+v.valorTotal+'</td>')
            .append('<td><input type="button" value="Apaga" id="' + dados.idEncomenda
                + '" onclick="apagaEncomenda(' + "'"+dados.idEncomenda+"'"+')"></td>')
            .append($t)
            .fadeIn('slow');
}

function obtemEncomenda()
{
    
  
     // alert("obtemEncomenda");
    var num =$('#num').val();
   
    if(num)
    { alert("obtemEncomenda: "+num);
        $.getJSON('http://localhost:8080/EComm/t1g1/orders/'+num, { get_param: 'value' }, function(data) {
        $.each(data, function(index, element) {
        $('body').append($('<div>', {
            text: element.name
        }));
    });
});
        
        
        
        
        
        
        
//        $.ajax({
//            url: 'http://localhost:8080/EComm/t1g1/orders/'+num,
//            type: 'GET',
//            dataType: 'JSON',
//            contetnType: 'application/json; charset=utf-8',
//            success: function(data){
//               // alert("data: "+data.keys().toString());
//                actualizaLinhaTabela(data);},
//            error: function(err) {
//                //alert(JSON.stringify(err));
//                msgErro(JSON.stringify(err));
//            }
//        });
    }else{
       
        msgErro("Introduza o númeor de aluno para iniciar a procura.");
        
    }
}
function actualizaLinhaTabela(dados)
{
   // alert("idEncomenda: "+ dados.idEncomenda);
    if(dados)
    {
        $('#num').val(dados.orderList);
        $('#nome').val(dados.moradaEncomenda);
        $('#nota').val(dados.observacoes);
    } else
        msgErro("Não encontrado...");
}

