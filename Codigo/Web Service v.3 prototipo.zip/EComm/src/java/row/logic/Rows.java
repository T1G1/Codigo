/**
 * Corredores
 *
 * @author Eduardo Fernandes
 */
package row.logic;

import bd.Bd;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.Singleton;
import javax.xml.bind.annotation.XmlRootElement;

@Singleton
@XmlRootElement
public class Rows {

    private HashMap<Integer, Row> rowList;

    public Rows() {
        this.rowList = new HashMap();
    }

    public Rows(HashMap<Integer, Row> rowList) {
        this.rowList = rowList;
    }

    public HashMap<Integer, Row> getRowList() {
        return rowList;
    }

    public void setRowList(HashMap<Integer, Row> rowList) {
        this.rowList = rowList;
    }

    public void addProduct(Row r) {
        this.rowList.put(r.getIdCorredor(), r);
    }

    public Collection<Row> getRows(Integer idStore) {
        try {
            Bd bd = new Bd();
            String query = "select * from corredor "
                    + "where idloja=" + idStore + ";";
            ResultSet result = bd.queryBd(query);
            while (result.next()) {
                Integer idCorredor = result.getInt("idCorredor");
                String desigCorredor = result.getString("desigCorredor");
                String descrCorredor = result.getString("descrCorredor");
                String imagem = result.getString("imagem");
                Row r = new Row(idCorredor, desigCorredor,
                        descrCorredor, imagem, idStore);
                this.rowList.put(idCorredor, r);
            }
            result.close();
            bd.closeBD();
            return this.rowList.values();
        } catch (SQLException ex) {
            Logger.getLogger(Rows.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    public Row getRow(Integer idRow) {
        Row r = new Row();

        try {
            Bd bd = new Bd();
            String query = "select * from corredor where "
                    + "idCorredor=" + idRow + ";";
            ResultSet result = bd.queryBd(query);
            while (result.next()) {
                r.setIdCorredor(idRow);
                r.setDesigCorredor(result.getString("desigCorredor"));
                r.setDescrCorredor(result.getString("descrCorredor"));
                r.setIdLoja(result.getInt("idLoja"));
                r.setImagem(result.getString("imagem"));
            }
            result.close();
            bd.closeBD();
            return r;
        } catch (SQLException ex) {
            Logger.getLogger(Rows.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    public void putRow(Row row) {
        try {
            Bd bd = new Bd();
            String query = "update corredor set"
                    + "idCorredor='"
                    + row.getIdCorredor() + "'"
                    + ", desigCorredor='"
                    + row.getDesigCorredor() + "'"
                    + ", descrCorredor='"
                    + row.getDescrCorredor() + "'"
                    + ", imagem='"
                    + row.getImagem() + "'"
                    + ", idLoja='"
                    + row.getIdLoja() + "'"
                    + " where idCorredor='"
                    + row.getIdCorredor() + "';";
            bd.updateBd(query);
        } catch (SQLException ex) {
            Logger.getLogger(Rows.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void postRow(Row row) {
        try {
            Bd bd = new Bd();
            String query = "INSERT INTO corredor "
                    + "(idCorredor, desigCorredor, "
                    + "descrCorredor, "
                    + "imagem, idloja"
                    + ") VALUES ('"
                    + row.getIdCorredor() + ", '"
                    + row.getDesigCorredor() + ", '"
                    + row.getDescrCorredor() + ", '"
                    + row.getImagem() + ", '"
                    + row.getIdLoja() + "';";
            bd.updateBd(query);
        } catch (SQLException ex) {
            Logger.getLogger(Rows.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
