/**
 * Corredor
 *
 * @author Eduardo Fernandes
 */
package row.logic;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Row {

    private Integer idCorredor;
    private String desigCorredor;
    private String descrCorredor;
    private String imagem;
    private Integer idLoja;

    public Row() {
    }

    public Row(Integer idCorredor, String desigCorredor, String descrCorredor, String imagem, Integer idLoja) {
        this.idCorredor = idCorredor;
        this.desigCorredor = desigCorredor;
        this.descrCorredor = descrCorredor;
        this.imagem = imagem;
        this.idLoja = idLoja;
    }

    public Integer getIdCorredor() {
        return idCorredor;
    }

    public void setIdCorredor(Integer idCorredor) {
        this.idCorredor = idCorredor;
    }

    public String getDesigCorredor() {
        return desigCorredor;
    }

    public void setDesigCorredor(String desigCorredor) {
        this.desigCorredor = desigCorredor;
    }

    public String getDescrCorredor() {
        return descrCorredor;
    }

    public void setDescrCorredor(String descrCorredor) {
        this.descrCorredor = descrCorredor;
    }

    public String getImagem() {
        return imagem;
    }

    public void setImagem(String imagem) {
        this.imagem = imagem;
    }

    public Integer getIdLoja() {
        return idLoja;
    }

    public void setIdLoja(Integer idLoja) {
        this.idLoja = idLoja;
    }

}
