/*
 * Prateleiras
 *
 * @author Eduardo Fernandes
 */
package row.logic;

import bd.Bd;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.Singleton;
import javax.xml.bind.annotation.XmlRootElement;

@Singleton
@XmlRootElement
public class Shelves {

    private HashMap<Integer, Shelf> sList;

    public Shelves() {
        this.sList = new HashMap();
    }

    public HashMap<Integer, Shelf> getsList() {
        return sList;
    }

    public void setsList(HashMap<Integer, Shelf> sList) {
        this.sList = sList;
    }

    public Collection<Shelf> getShelves(Integer idRow) {
        try {
            Bd bd = new Bd();
            String query = "select idPrateleira,"
                        + "idCorredor,"
                        + "desigPrateleira,"
                        + "descrPrateleira"
                        + ",imagem from prateleira "
                        + "where idCorredor=" + idRow + ";";
            
            ResultSet result = bd.queryBd(query);
            while (result.next()) {
                Integer idCorredor = result.getInt("idCorredor");
                Integer idPrateleira = result.getInt("idPrateleira");
                String desigPrateleira = result.getString("desigPrateleira");
                String descrPrateleira = result.getString("descrPrateleira");
                String imagem = result.getString("imagem");
                Shelf s = new Shelf(idPrateleira, idCorredor, desigPrateleira,
                        descrPrateleira, imagem);
                this.sList.put(idPrateleira, s);  
            }
            result.close();
            bd.closeBD();
            return this.sList.values();
        } catch (SQLException ex) {
            Logger.getLogger(Rows.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    public Shelf getShelf(Integer idShelf) {
        Shelf s = new Shelf();

        try {
            Bd bd = new Bd();
            String query = "select * from prateleira where "
                        + "idPrateleira=" + idShelf + ";";
            ResultSet result = bd.queryBd(query);
            while (result.next()) {
                s.setIdPrateleira(idShelf);
                s.setIdCorredor(result.getInt("idCorredor"));
                s.setDesigPrateleira(result.getString("desigPrateleira"));
                s.setDescrPrateleira(result.getString("descrPrateleira"));
                s.setImagem(result.getString("imagem"));
            }
            result.close();
            bd.closeBD();
            return s;
        } catch (SQLException ex) {
            Logger.getLogger(Rows.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    public void putShelf(Shelf shelf) {
        System.out.println("[DEBUG]: PUT method");
        try {
            Bd bd = new Bd();
            String query = "update prateleira set"
                        + "idCorredor='" 
                        + shelf.getIdCorredor() + "'"
                        + ", desigPrateleira='" 
                        + shelf.getDesigPrateleira() + "'"
                        + ", descrPrateleira='" 
                        + shelf.getDescrPrateleira() + "'"
                        + ", imagem='" 
                        + shelf.getImagem() + "'"
                        + ", idPrateleira='" 
                        + shelf.getIdPrateleira() + "'"
                        + " where idCorredor='" 
                        + shelf.getIdCorredor() + "';";
            bd.updateBd(query);
        } catch (SQLException ex) {
            Logger.getLogger(Rows.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void postShelf(Shelf shelf) {
        try {
            Bd bd = new Bd();
            String query = "insert into prateleira ("
                        + "idCorredor, "
                        + "desigPrateleira, "
                        + "descrPrateleira, "
                        + "imagem) "
                        + "VALUES ('"
                        + shelf.getIdPrateleira() + "' ,'"
                        + shelf.getDesigPrateleira() + "' ,'"
                        + shelf.getDescrPrateleira() + "' ,'"
                        + shelf.getImagem() + "'"
                        + ")";
            bd.updateBd(query);
        } catch (SQLException ex) {
            Logger.getLogger(Shelves.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
