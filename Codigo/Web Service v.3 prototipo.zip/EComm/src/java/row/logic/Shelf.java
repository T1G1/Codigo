/**
 * Prateleira
 *
 * @author Eduardo Fernandes
 */
package row.logic;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Shelf {

    private Integer idPrateleira;
    private Integer idCorredor;
    private String desigPrateleira;
    private String descrPrateleira;
    private String imagem;

    public Shelf() {
    }

    public Shelf(Integer idPrateleira, Integer idCorredor, String desigPrateleira, String descrPrateleira, String imagem) {
        this.idPrateleira = idPrateleira;
        this.idCorredor = idCorredor;
        this.desigPrateleira = desigPrateleira;
        this.descrPrateleira = descrPrateleira;
        this.imagem = imagem;
    }

    public Integer getIdPrateleira() {
        return idPrateleira;
    }

    public void setIdPrateleira(Integer idPrateleira) {
        this.idPrateleira = idPrateleira;
    }

    public Integer getIdCorredor() {
        return idCorredor;
    }

    public void setIdCorredor(Integer idCorredor) {
        this.idCorredor = idCorredor;
    }

    public String getDesigPrateleira() {
        return desigPrateleira;
    }

    public void setDesigPrateleira(String desigPrateleira) {
        this.desigPrateleira = desigPrateleira;
    }

    public String getDescrPrateleira() {
        return descrPrateleira;
    }

    public void setDescrPrateleira(String descrPrateleira) {
        this.descrPrateleira = descrPrateleira;
    }

    public String getImagem() {
        return imagem;
    }

    public void setImagem(String imagem) {
        this.imagem = imagem;
    }

}
