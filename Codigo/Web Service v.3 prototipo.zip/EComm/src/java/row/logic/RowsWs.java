/**
 * REST Web Service
 *
 * Corredores
 * e
 * Prateleiras
 *
 * @author Eduardo Fernandes
 */
package row.logic;

import java.util.Collection;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

@Path("rows")
public class RowsWs {

    @Context
    private UriInfo context;
    private final row.logic.Rows rList = new row.logic.Rows();
    private final row.logic.Shelves sList = new row.logic.Shelves();

    public RowsWs() {
    }

    /**
     * Devolve uma coleção de CORREDOR
     *
     * @param idStore - query parameter identificador da LOJA
     * @return JSON
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Collection<Row> getRows(@QueryParam("idStore") Integer idStore) {

        return rList.getRows(idStore);

    }

    /**
     * Devolve um CORREDOR
     *
     * @param idRow - path parameter identificador do CORREDOR
     * @return JSON
     */
    @Path("/{idRow}")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Row getRow(@PathParam("idRow") int idRow) {
        return rList.getRow(idRow);
    }

    /**
     * Devolve uma coleção de PRATELEIRA
     *
     * @param idRow - path parameter identificador do CORREDOR
     * @return JSON
     */
    @Path("/{idRow}/shelves")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Collection<Shelf> getShelves(@PathParam("idRow") int idRow) {
        return sList.getShelves(idRow);
    }

    /**
     * Devolve uma PRATELEIRA
     *
     * @param idShelf - path parameter identificador da PRATELEIRA
     * @return JSON
     */
    @Path("/{idRow}/shelves/{idShelf}")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Shelf getShelf(@PathParam("idShelf") int idShelf) {
        return sList.getShelf(idShelf);
    }

    /**
     * PUT método para alterar um CORREDOR
     *
     * @param row - objeto JSON que representa o CORREDOR
     */
    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    public void putRow(Row row) {
        rList.putRow(row);
    }

    /**
     * POST método para inserir uma PRATELEIRA
     *
     * @param shelf - objeto JSON que representa a PRATELEIRA
     */
    @Path("/{idRow}/shelves/")
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public void postShelf(Shelf shelf) {
        sList.postShelf(shelf);

    }
}
