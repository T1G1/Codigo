/**
 * Encomenda
 *
 * @author Eduardo Fernandes
 */
package order.logic;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Order {

    private Integer idEncomenda;
    private Integer idCliente;
    private Integer idTipoPagLoja;
    private Integer codPagamento;
    private Float custoEntrega;
    private Integer codDespacho;
    private Float txIvaEntr;
    private Float valorTotal;
    private String moradaEntrega;
    private String codPostal;
    private String observacoes;
    private Integer tipoentr_loja_idTipoEntrLoja;

    public Order() {
    }

    public Order(Integer idEncomenda, Integer idCliente, Integer idTipoPagLoja, Integer codPagamento, Float custoEntrega, Integer codDespacho, Float txIvaEntr, Float valorTotal, String moradaEntrega, String codPostal, String observacoes, Integer tipoentr_loja_idTipoEntrLoja) {
        this.idEncomenda = idEncomenda;
        this.idCliente = idCliente;
        this.idTipoPagLoja = idTipoPagLoja;
        this.codPagamento = codPagamento;
        this.custoEntrega = custoEntrega;
        this.codDespacho = codDespacho;
        this.txIvaEntr = txIvaEntr;
        this.valorTotal = valorTotal;
        this.moradaEntrega = moradaEntrega;
        this.codPostal = codPostal;
        this.observacoes = observacoes;
        this.tipoentr_loja_idTipoEntrLoja = tipoentr_loja_idTipoEntrLoja;
    }

    public Integer getIdEncomenda() {
        return idEncomenda;
    }

    public void setIdEncomenda(Integer idEncomenda) {
        this.idEncomenda = idEncomenda;
    }

    public Integer getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(Integer idCliente) {
        this.idCliente = idCliente;
    }

    public Integer getIdTipoPagLoja() {
        return idTipoPagLoja;
    }

    public void setIdTipoPagLoja(Integer idTipoPagLoja) {
        this.idTipoPagLoja = idTipoPagLoja;
    }

    public Integer getCodPagamento() {
        return codPagamento;
    }

    public void setCodPagamento(Integer codPagamento) {
        this.codPagamento = codPagamento;
    }

    public Float getCustoEntrega() {
        return custoEntrega;
    }

    public void setCustoEntrega(Float custoEntrega) {
        this.custoEntrega = custoEntrega;
    }

    public Integer getCodDespacho() {
        return codDespacho;
    }

    public void setCodDespacho(Integer codDespacho) {
        this.codDespacho = codDespacho;
    }

    public Float getTxIvaEntr() {
        return txIvaEntr;
    }

    public void setTxIvaEntr(Float txIvaEntr) {
        this.txIvaEntr = txIvaEntr;
    }

    public Float getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(Float valorTotal) {
        this.valorTotal = valorTotal;
    }

    public String getMoradaEntrega() {
        return moradaEntrega;
    }

    public void setMoradaEntrega(String moradaEntrega) {
        this.moradaEntrega = moradaEntrega;
    }

    public String getCodPostal() {
        return codPostal;
    }

    public void setCodPostal(String codPostal) {
        this.codPostal = codPostal;
    }

    public String getObservacoes() {
        return observacoes;
    }

    public void setObservacoes(String observacoes) {
        this.observacoes = observacoes;
    }

    public Integer getTipoentr_loja_idTipoEntrLoja() {
        return tipoentr_loja_idTipoEntrLoja;
    }

    public void setTipoentr_loja_idTipoEntrLoja(Integer tipoentr_loja_idTipoEntrLoja) {
        this.tipoentr_loja_idTipoEntrLoja = tipoentr_loja_idTipoEntrLoja;
    }

}
