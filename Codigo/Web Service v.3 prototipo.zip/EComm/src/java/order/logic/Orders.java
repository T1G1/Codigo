/*
 * Encomendas
 *
 * @author Eduardo Fernandes
 */
package order.logic;

import bd.Bd;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.Singleton;
import javax.xml.bind.annotation.XmlRootElement;

@Singleton
@XmlRootElement
public class Orders {

    private HashMap<Integer, Order> orderList;

    public Orders() {
        this.orderList = new HashMap();
    }

    public HashMap<Integer, Order> getOrderList() {
        return orderList;
    }

    public void setOrderList(HashMap<Integer, Order> orders) {
        this.orderList = orders;
    }

    public Collection<Order> getEncomendasCliente(Integer idCliente) {
        try {
            Bd bd = new Bd();
            String query = "select * from encomendas where idCliente='" + idCliente + "';";
            System.out.println("[DEBUG]1: ." + query);
            ResultSet result = bd.queryBd(query);
            while (result.next()) {
                Integer idEncomenda = result.getInt("idEncomenda");
                //Integer idCliente=result.getInt("idCliente");
                Integer idTipoPagLoja = result.getInt("idTipoPagLoja");
                Integer codPagamento = result.getInt("codPagamento");
                Float custoEntrega = result.getFloat("custoEntrega");
                Integer codDespacho = result.getInt("codDespacho");
                Float txIvaEntr = result.getFloat("txIvaEntr");
                Float valorTotal = result.getFloat("valorTotal");
                String moradaEntrega = result.getString("moradaEntrega");
                String codPostal = result.getString("codpostal");
                String observacoes = result.getString("observacoes");
                Integer tipoentr_loja_idTipoEntrLoja
                        = result.getInt("tipoentr_loja_idTipoEntrLoja");

                Order o = new Order(idEncomenda, idCliente, idTipoPagLoja,
                        codPagamento, custoEntrega, codDespacho, txIvaEntr,
                        valorTotal, moradaEntrega, codPostal, observacoes,
                        tipoentr_loja_idTipoEntrLoja);
                this.orderList.put(idEncomenda, o);
                System.out.println("[DEBUG]: Carregou uma linha."
                        + result.getString("idEncomenda"));

            }
            result.close();
            bd.closeBD();
            return this.orderList.values();
        } catch (SQLException ex) {
            Logger.getLogger(Orders.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    public Collection<Order> getBdOrderList() {
        try {
            Bd bd = new Bd();
            String query = "select * from encomendas;";
            System.out.println("[DEBUG]1: ." + query);
            ResultSet result = bd.queryBd(query);
            while (result.next()) {
                Integer idEncomenda = result.getInt("idEncomenda");
                Integer idCliente = result.getInt("idCliente");
                Integer idTipoPagLoja = result.getInt("idTipoPagLoja");
                Integer codPagamento = result.getInt("codPagamento");
                Float custoEntrega = result.getFloat("custoEntrega");
                Integer codDespacho = result.getInt("codDespacho");
                Float txIvaEntr = result.getFloat("txIvaEntr");
                Float valorTotal = result.getFloat("valorTotal");
                String moradaEntrega = result.getString("moradaEntrega");
                String codPostal = result.getString("codpostal");
                String observacoes = result.getString("observacoes");
                Integer tipoentr_loja_idTipoEntrLoja
                        = result.getInt("tipoentr_loja_idTipoEntrLoja");

                Order o = new Order(idEncomenda, idCliente, idTipoPagLoja,
                        codPagamento, custoEntrega, codDespacho, txIvaEntr,
                        valorTotal, moradaEntrega, codPostal, observacoes,
                        tipoentr_loja_idTipoEntrLoja);
                this.orderList.put(idEncomenda, o);
            }
            result.close();
            bd.closeBD();
            return this.orderList.values();
        } catch (SQLException ex) {
            Logger.getLogger(Orders.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    public Order getOrder(Integer idEncomenda) {
        try {
            Bd bd = new Bd();
            String query = "select * from encomendas where idEncomenda='" + idEncomenda + "';";
            System.out.println("[DEBUG]1: ." + query);
            ResultSet result = bd.queryBd(query);
            while (result.next()) {
                //Integer idEncomenda=result.getInt("idEncomenda");
                Integer idCliente = result.getInt("idCliente");
                Integer idTipoPagLoja = result.getInt("idTipoPagLoja");
                Integer codPagamento = result.getInt("codPagamento");
                Float custoEntrega = result.getFloat("custoEntrega");
                Integer codDespacho = result.getInt("codDespacho");
                Float txIvaEntr = result.getFloat("txIvaEntr");
                Float valorTotal = result.getFloat("valorTotal");
                String moradaEntrega = result.getString("moradaEntrega");
                String codPostal = result.getString("codpostal");
                String observacoes = result.getString("observacoes");
                Integer tipoentr_loja_idTipoEntrLoja
                        = result.getInt("tipoentr_loja_idTipoEntrLoja");

                Order o = new Order(idEncomenda, idCliente, idTipoPagLoja,
                        codPagamento, custoEntrega, codDespacho, txIvaEntr,
                        valorTotal, moradaEntrega, codPostal, observacoes,
                        tipoentr_loja_idTipoEntrLoja);
                return o;
            }
            result.close();
            bd.closeBD();

        } catch (SQLException ex) {
            Logger.getLogger(Orders.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    public Integer setOrder(Order order) {
        try {
            System.out.println("[DEBUG]: Vou tentar adicionar uma linha.");
            //Integer idEncomenda=order.getIdEncomenda();
            Integer idCliente = order.getIdCliente();
            Integer idTipoPagLoja = order.getIdTipoPagLoja();
            Integer codPagamento = order.getCodPagamento();
            Float custoEntrega = order.getCustoEntrega();
            Integer codDespacho = order.getCodDespacho();
            Float txIvaEntr = order.getTxIvaEntr();
            Float valorTotal = order.getValorTotal();
            String moradaEntrega = order.getMoradaEntrega();
            String codPostal = order.getCodPostal();
            String observacoes = order.getObservacoes();
            Integer tipoentr_loja_idTipoEntrLoja
                    = order.getTipoentr_loja_idTipoEntrLoja();
            String query = "INSERT INTO encomendas("
                    + "idCliente,idTipoPagLoja,"
                    + "codPagamento,custoEntrega,codDespacho,"
                    + "txIvaEntr,codPagamento,valorTotal,"
                    + "moradaEntrega,codPostal,observacoes,"
                    + "tipoentr_loja_idTipoEntrLoja)"
                    + "VALUES("
                    + "'" + idCliente + "',"
                    + "'" + idTipoPagLoja + "',"
                    + "'" + codPagamento + "',"
                    + "'" + custoEntrega + "',"
                    + "'" + codDespacho + "',"
                    + "'" + txIvaEntr + "',"
                    + "'" + codPagamento + "',"
                    + "'" + valorTotal + "',"
                    + "'" + moradaEntrega + "',"
                    + "'" + codPostal + "',"
                    + "'" + observacoes + ""
                    + "'" + tipoentr_loja_idTipoEntrLoja + ""
                    + "');";
            Bd bd = new Bd();
            bd.updateBd(query);
            System.out.println("[DEBUG]: Adicionou uma linha.");
            bd.closeBD();
        } catch (SQLException ex) {
            Logger.getLogger(Orders.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
        return 0;
    }

    public Integer putOrder(Order order) {
        try {
            System.out.println("[DEBUG]: Vou tentar alterar uma linha.");
            Integer idEncomenda = order.getIdEncomenda();
            Integer idCliente = order.getIdCliente();
            Integer idTipoPagLoja = order.getIdTipoPagLoja();
            Integer codPagamento = order.getCodPagamento();
            Float custoEntrega = order.getCustoEntrega();
            Integer codDespacho = order.getCodDespacho();
            Float txIvaEntr = order.getTxIvaEntr();
            Float valorTotal = order.getValorTotal();
            String moradaEntrega = order.getMoradaEntrega();
            String codPostal = order.getCodPostal();
            String observacoes = order.getObservacoes();
            Integer tipoentr_loja_idTipoEntrLoja
                    = order.getTipoentr_loja_idTipoEntrLoja();
            String query = "UPDATE encomendas SET "
                    + "idCliente='" + idCliente + "',"
                    + "idTipoPagLoja='" + idTipoPagLoja + "',"
                    + "codPagamento='" + codPagamento + "',"
                    + "custoEntrega='" + custoEntrega + "',"
                    + "codDespacho='" + codDespacho + "',"
                    + "txIvaEntr='" + txIvaEntr + "',"
                    + "codPagamento='" + codPagamento + "',"
                    + "valorTotal='" + valorTotal + "',"
                    + "moradaEntrega='" + moradaEntrega + "',"
                    + "codPostal='" + codPostal + "',"
                    + "observacoes='" + observacoes + "',"
                    + "tipoentr_loja_idTipoEntrLoja="
                    + "'" + tipoentr_loja_idTipoEntrLoja + ""
                    + "' WHERE "
                    + "idEncomenda='" + idEncomenda + "';";

            Bd bd = new Bd();
            bd.updateBd(query);
            System.out.println("[DEBUG]: Adicionou uma linha.");
            bd.closeBD();
        } catch (SQLException ex) {
            Logger.getLogger(Orders.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
        return 0;
    }

}
