/**
 * REST Web Service
 *
 * Encomendas
 *
 * @author Eduardo Fernandes
 */
package order.logic;

import java.util.Collection;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;

@Path("orders")
public class OrdersWs {

    @Context
    private UriInfo context;
    private final order.logic.Orders orderList = new order.logic.Orders();

    public OrdersWs() {
    }

    /**
     * Devolve uma coleção de ENCOMENDA
     *
     * @param idStore - query parameter identificador da LOJA
     * @return JSON
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Collection<Order> getJson() {
        System.out.println("[DEBUG]:" + orderList.toString());
        return orderList.getBdOrderList();
    }

    /**
     * Devolve uma coleção de ENCOMENDA de um CLIENTE
     *
     * @param idCustomer - query parameter identificador do CLIENTE
     * @return JSON
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/customer/{idCustomer}")
    public Collection<Order> getOrdersCustomer(@PathParam("idCustomer") int num) {
        return orderList.getEncomendasCliente(num);
    }

    /**
     * Devolve uma ENCOMENDA
     *
     * @param idOrder - path parameter identificador da ENCOMENDA
     * @return JSON
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Path("/{idOrder}")
    public Order getOrder(@PathParam("idOrder") int num) {
        return orderList.getOrder(num);
        // return orderList;
    }

    /**
     * PUT método para alterar uma ENCOMENDA
     *
     * @param order - objeto JSON que representa a ENCOMENDA
     */
    @PUT
    @Path("/{idOrder}")
    @Consumes(MediaType.APPLICATION_JSON)
    public void putJson(Order order) {
        System.out.println("[DEBUG]: Vou tentar alterar uma linha.");
        orderList.putOrder(order);
    }

    /**
     * POST método para inserir uma ENCOMENDA
     *
     * @param order - objeto JSON que representa a ENCOMENDA
     */
    @POST
    @Path("{idOrder}")
    @Consumes(MediaType.APPLICATION_JSON)
    public void postJson(Order order) {
        orderList.setOrder(order);
    }

}
