/**
 * REST Web Service
 *
 * Produtos
 *
 * @author Eduardo Fernandes
 */
package product.logic;

import java.util.Collection;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

@Path("products")
public class ProductsWs {

    @Context
    private UriInfo context;
    private final Products pList = new Products();

    public ProductsWs() {
    }

    /**
     * Devolve uma coleção de PRODUTO
     *
     * @param idStore - query parameter identificador da LOJA
     * @return JSON
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Collection<Product> getProducts(@QueryParam("idStore") Integer idStore) {
        return pList.getBdProductList(idStore);
    }

    /**
     * Devolve um PRODUTO
     *
     * @param idProduct - path parameter identificador do PRODUTO
     * @return JSON
     */
    @Path("{idProduct}")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Product getProduct(@PathParam("idProduct") int idProduct) {
        return pList.getProduct(idProduct);
    }

    /**
     * PUT método para alterar um PRODUTO
     *
     * @param prod - objeto JSON que representa o PRODUTO
     */
    @PUT
    @Path("{idProduct}")
    @Consumes(MediaType.APPLICATION_JSON)
    public void putJson(Product prod) {
        pList.putProduct(prod);
    }
}
