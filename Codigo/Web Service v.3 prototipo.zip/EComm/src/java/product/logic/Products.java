/*
 * Produtos
 *
 * @author Eduardo Fernandes
 */
package product.logic;

import bd.Bd;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.Singleton;
import javax.xml.bind.annotation.XmlRootElement;

@Singleton
@XmlRootElement
public class Products {

    private HashMap<Integer, Product> productList;

    public Products() {
        this.productList = new HashMap();
    }

    public HashMap<Integer, Product> getProdutcList() {
        return productList;
    }

    public void setProductList(HashMap<Integer, Product> products) {
        this.productList = products;
    }

    public void addProduct(Product p) {
        this.productList.put(p.getIdProduto(), p);
    }

    public Collection<Product> getBdProductList(Integer idStore) {
        try {
            Bd bd = new Bd();
            String query = "select  p.idProduto, p.desigProduto,"
                    + "p.idMarca ,"
                    + " p.modelo ,"
                    + " p.informacaoProduto ,"
                    + " p.precoUnit,"
                    + " p.idTaxa ,"
                    + " p.unid1 ,"
                    + " p.taxaconvercao,"
                    + " p.unid2 ,"
                    + " p.stockActual,"
                    + " p.stockMinimo ,"
                    + " p.imagemPesquisa,"
                    + " p.idPrateleira "
                    + " from produtos as p"
                    + " inner join prateleira as pr"
                    + " on p.idPrateleira = pr.idPrateleira"
                    + " inner join corredor as c"
                    + " on pr.idCorredor = c.idCorredor"
                    + " where c.idLoja='" + idStore + "'; ";
            ResultSet result = bd.queryBd(query);
            while (result.next()) {
                Integer idProduto = result.getInt("idProduto");
                String desigProduto = result.getString("desigProduto");
                Integer idMarca = result.getInt("idMarca");
                String modelo = result.getString("modelo");
                String informacaoProduto = result.getString("informacaoProduto");
                Float precoUnit = result.getFloat("precoUnit");
                String idTaxa = result.getString("idTaxa");
                String unid1 = result.getString("unid1");
                Float taxaconvercao = result.getFloat("taxaconvercao");
                String unid2 = result.getString("unid2");
                Float stockActual = result.getFloat("stockActual");
                Float stockMinimo = result.getFloat("stockMinimo");
                String imagemPesquisa = result.getString("imagemPesquisa");
                Integer idPrateleira = result.getInt("idPrateleira");
                Product p = new Product(idProduto, desigProduto, idMarca,
                        modelo, informacaoProduto,
                        precoUnit, idTaxa, unid1,
                        taxaconvercao, unid2, stockActual,
                        stockMinimo, imagemPesquisa, idPrateleira);
                this.productList.put(idProduto, p);
            }
            result.close();
            bd.closeBD();
            return this.productList.values();

        } catch (SQLException ex) {
            Logger.getLogger(Products.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    public Product getProduct(Integer idProduto) {
        Product p = new Product();
        try {
            Bd bd = new Bd();
            String query = "select * from produtos where "
                    + "idProduto=" + idProduto + ";";
            System.out.println("[DEBUG]1: ." + query);
            ResultSet result = bd.queryBd(query);
            while (result.next()) {
                p.setIdProduto(result.getInt("idProduto"));
                p.setDesigProduto(result.getString("desigProduto"));
                p.setIdMarca(result.getInt("idMarca"));
                p.setModelo(result.getString("modelo"));
                p.setInformacaoProduto(result.getString("informacaoProduto"));
                p.setPrecoUnit(result.getFloat("precoUnit"));
                p.setIdTaxa(result.getString("idTaxa"));
                p.setUnid1(result.getString("unid1"));
                p.setTaxaConvercao(result.getFloat("taxaconvercao"));
                p.setUnid2(result.getString("unid2"));
                p.setStockActual(result.getFloat("stockActual"));
                p.setStockMinimo(result.getFloat("stockMinimo"));
                p.setImagemPesquisa(result.getString("imagemPesquisa"));
                p.setIdPrateleira(result.getInt("idPrateleira"));
            }
            result.close();
            bd.closeBD();
            return p;
        } catch (SQLException ex) {
            Logger.getLogger(Products.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    public void putProduct(Product product) {
        try {
            Bd bd = new Bd();
            String query = "update produtos set"
                        + " desigProduto='"
                    + product.getDesigProduto() + "'"
                    + ", idMarca='"
                    + product.getIdMarca() + "'"
                    + ", modelo='"
                    + product.getModelo() + "'"
                    + ", informacaoProduto='"
                    + product.getInformacaoProduto() + "'"
                    + ", precoUnit='"
                    + product.getPrecoUnit() + "'"
                    + ", idTaxa='"
                    + product.getIdTaxa() + "'"
                    + ", unid1='"
                    + product.getUnid1() + "'"
                    + ", taxaconvercao='"
                    + product.getTaxaConvercao() + "'"
                    + ", unid2='"
                    + product.getUnid2() + "'"
                    + ", stockActual='"
                    + product.getStockActual() + "'"
                    + ", stockMinimo='"
                    + product.getStockMinimo() + "'"
                    + ", imagemPesquisa='"
                    + product.getImagemPesquisa() + "'"
                    + ", idPrateleira='"
                    + product.getIdPrateleira() + "'"
                    + " where idProduto='"
                    + product.getIdProduto() + "';";
            bd.updateBd(query);
        } catch (SQLException ex) {
            Logger.getLogger(Products.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
}
