/**
 * Acesso à Base de Dados
 *
 * Dados da conecção nas variáveis
 * localizacao, nome, pass, bdName
 *
 * @author Eduardo Fernandes
 */
package bd;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Bd {

    private final String localizacao = "localhost:3306";
    private final String nome = "root";
    private final String pass = "qualificait1";
    private final String bdName = "t1g1";
    private Connection conn;
    private Statement stmt;

    public Bd() throws SQLException {
        conn = DriverManager.getConnection("jdbc:mysql://" + localizacao
                + "/" + bdName, nome, pass);
        stmt = conn.createStatement();
    }

    public boolean closeBD() {
        boolean result = false;
        try {
            stmt.close();
            conn.close();
            result = true;
        } catch (SQLException ex) {
            Logger.getLogger(Bd.class.getName()).log(Level.SEVERE, null, ex);
        }
        return result;
    }

    public ResultSet queryBd(String query) throws SQLException {
        ResultSet result = null;
        result = stmt.executeQuery(query);
        return result;
    }

    public void updateBd(String query) throws SQLException {
        stmt.executeUpdate(query);
    }
}
